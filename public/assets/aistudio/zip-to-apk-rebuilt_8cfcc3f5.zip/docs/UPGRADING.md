# If your phone still shows the old app name

A workflow file cannot be updated by uploading a zip, because GitHub only reads `.github/workflows/build.yml` from the repository itself. And an old `android/` folder in the repository keeps its old app name, package name and icon, because it is only generated once. That is why an APK can still show the old app name and the old package name even when the app code is new. Fix both, in this order. Everything works from the GitHub website on a phone.

1. **Delete the old `android` folder** from the repository: open the repo, open the `android` folder, tap the three dots, choose *Delete directory*, commit. The new build creates it fresh. This alone fixes the app name, package name, data folder and icon.
2. **Replace the workflow file:** open `.github/workflows/build.yml`, tap the pencil, select everything, paste the contents of the `build.yml` that came with this update, commit. The new one also picks the newest zip (or your loose files if they are newer), regenerates `android/` every time, and refuses to publish an APK whose name or package does not match `capacitor.config.json`.
3. **Delete old zips** you no longer need from the repository root, so they cannot be built by mistake.
4. **Run it:** Actions, *Build APKs*, *Run workflow*. When it finishes, open the run summary. It lists the app name, the package and the data folder of the APK it built. They should read `Zip to APK` and `com.ziphtml.apkconverter`.
5. **On the phone,** uninstall the old app and install the new APK. It has a different package name, so Android treats it as a separate app.

If the app ever opens to a blank screen, it now waits 8 seconds and then shows what went wrong. Open Settings, *Connection check* tells you whether the account service and the build service answer.

---

# Upgrading from the previous version

Read this before you deploy. A few things behave differently on purpose.

## Do these in order

1. **Push the new workflow first**, then deploy the new Worker. The Worker now sends one extra input (`build_config`) that the old workflow does not know, and GitHub rejects unknown inputs.
2. **Set the `WORKER_URL` repository variable.** The old code had a Worker address written into the source, and the setting never took effect. The address is no longer in the code, so until you set the variable the app builds fine but the Build button stays off.
3. **Add a Cron Trigger** (`*/10 * * * *`) to the Worker. `wrangler.toml` does this for you. It closes builds that stopped reporting and returns their credit.
4. **Switch off the old master coupon** in your live database, because it hands out the Pro plan to anyone who knows the code:
   ```sql
   update public.coupons set active = false where code = 'FIRST ME';
   ```

## What changes for people

- **New app identity.** The Android app id is now `com.ziphtml.apkconverter`. Android treats it as a different app, so people install the new one next to the old one and can remove the old one.
- **New generated package names.** Free builds now get `com.ziphtml.u<id>`. An app built earlier under the previous generated name will not update in place when rebuilt, because Android sees a new app.
- **Saved projects.** Projects stored in a browser under the old storage key are not carried over. They were drafts and history only; finished APKs are untouched and still listed under Recent builds.
- **Source upload limit** is 50 MB (it was shown as 100 MB, but the storage bucket always refused anything above 50 MB).

## What is new in how builds behave

- The options in the wizard are now applied. Before, only name, version and package name reached the build. Orientation, permissions, deep links, minimum Android version, WebView options and the icon are sent to the build and written into the Android project.
- Website URL, PWA, APK and AAB source types and the Release APK and AAB outputs are gone from the wizard. The pipeline never supported them, so the wizard let people finish all the steps and then failed. They will return when the pipeline can build them.
- `package-lock.json` is not included, because the dependency list changed. Run `npm install` once and commit the file it creates.
