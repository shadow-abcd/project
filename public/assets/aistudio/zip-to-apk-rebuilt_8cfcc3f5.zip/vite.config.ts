import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

const root = path.dirname(fileURLToPath(import.meta.url));
const pkg = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf-8')) as { version: string };

// base "./" keeps the build working inside the Android WebView and on any sub-path host.
export default defineConfig({
  base: './',
  plugins: [react()],
  define: { __APP_VERSION__: JSON.stringify(pkg.version) },
  resolve: { alias: { '@': path.resolve(root, 'src') } },
  build: {
    target: 'es2020',
    // One bundle on purpose. The app is served from the phone itself, so splitting it saves nothing,
    // and hand-made vendor chunks can create circular imports that leave the page blank.
    chunkSizeWarningLimit: 1200,
  },
});
