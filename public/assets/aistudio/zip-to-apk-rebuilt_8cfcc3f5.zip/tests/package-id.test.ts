import assert from 'node:assert/strict';
import test from 'node:test';
import {
  packageWarning,
  sanitizeAppName,
  slugify,
  suggestPackageId,
  validatePackageId,
  validateVersionName,
} from '../src/lib/package-id.ts';

test('accepts normal package names', () => {
  assert.equal(validatePackageId('com.yourname.app'), null);
  assert.equal(validatePackageId('  Com.YourName.App '), null); // normalised first
  assert.equal(validatePackageId('a.b'), null);
  assert.equal(validatePackageId('com.my_app.v2'), null);
});

test('rejects malformed names', () => {
  assert.ok(validatePackageId(''));
  assert.ok(validatePackageId('singleword'));
  assert.ok(validatePackageId('com..app'));
  assert.ok(validatePackageId('com.1app.main'));
  assert.ok(validatePackageId('com.my-app.main'));
  assert.ok(validatePackageId(`com.${'a'.repeat(100)}.app`));
});

test('rejects Java reserved words in any segment', () => {
  assert.match(validatePackageId('com.new.app') ?? '', /reserved/);
  assert.match(validatePackageId('com.mysite.class') ?? '', /reserved/);
  assert.match(validatePackageId('int.company.app') ?? '', /reserved/);
});

test('warns about names Google Play refuses', () => {
  assert.ok(packageWarning('com.example.app'));
  assert.ok(packageWarning('com.android.tool'));
  assert.equal(packageWarning('com.acme.app'), null);
});

test('suggested ids are always valid', () => {
  for (const name of ['My Notes', 'Tom & Jerry', '123 Go', 'New', 'Über Café', '日本語', '', '   ', 'class']) {
    const id = suggestPackageId(name);
    assert.equal(validatePackageId(id), null, `${JSON.stringify(name)} -> ${id}`);
  }
  assert.equal(suggestPackageId('My Notes'), 'com.mynotes.app');
});

test('version names', () => {
  assert.equal(validateVersionName('1.0.0'), null);
  assert.equal(validateVersionName('2.1-beta_3'), null);
  assert.ok(validateVersionName(''));
  assert.ok(validateVersionName('1.0 beta'));
  assert.ok(validateVersionName('x'.repeat(21)));
});

test('app names are cleaned', () => {
  assert.equal(sanitizeAppName('  My   App\u0000\n '), 'My App');
  assert.equal(sanitizeAppName('x'.repeat(50)).length, 30);
});

test('slugify', () => {
  assert.equal(slugify('My Great App!'), 'my-great-app');
  assert.equal(slugify('!!!'), 'app');
});
