import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import test from 'node:test';
import worker, { reapStaleJobs } from '../worker/worker.js';

/* The Worker is exercised end to end with a fake Supabase and a fake GitHub. */

const env: any = {
  SUPABASE_URL: 'https://proj.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_test',
  SUPABASE_SERVICE_ROLE_KEY: 'sb_secret_test',
  GITHUB_TOKEN: 'ghp_test',
  GITHUB_REPO: 'owner/repo',
};
const USER = '11111111-2222-3333-4444-555555555555';
const JOB = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee';

interface World {
  plan: string;
  openJobs: number;
  charged: boolean;
  dispatchStatus: number;
  calls: Array<{ url: string; method: string; body: any; headers: Record<string, string> }>;
  jobs: any[];
  stale: any[];
}

function install(world: Partial<World> = {}) {
  const w: World = { plan: 'free', openJobs: 0, charged: true, dispatchStatus: 204, calls: [], jobs: [], stale: [], ...world };
  const original = globalThis.fetch;
  globalThis.fetch = (async (input: any, init: any = {}) => {
    const url = String(typeof input === 'string' ? input : input.url);
    const method = init.method || 'GET';
    let body: any = init.body;
    if (typeof body === 'string') {
      try { body = JSON.parse(body); } catch { /* leave as text */ }
    }
    w.calls.push({ url, method, body, headers: init.headers || {} });
    const reply = (data: any, status = 200) => new Response(status === 204 ? null : JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } });

    if (url.endsWith('/auth/v1/user')) return reply({ id: USER });
    if (url.includes('/rest/v1/profiles')) return reply([{ plan: w.plan }]);
    if (url.includes('/rest/v1/build_jobs?user_id=')) return reply(Array.from({ length: w.openJobs }, (_, i) => ({ id: `j${i}` })));
    if (url.includes('/rpc/consume_credit')) return reply({ charged: w.charged, credits: 0 });
    if (url.includes('/rpc/refund_credit')) return reply({});
    if (url.includes('/rest/v1/build_jobs') && method === 'POST') return reply([{ id: JOB }], 201);
    if (url.includes('/rest/v1/build_jobs?status=in.')) return reply(w.stale);
    if (url.includes('/rest/v1/build_jobs') && method === 'PATCH') return reply([{ id: 'patched' }]);
    if (url.includes('/rest/v1/build_jobs?id=eq.')) return reply(w.jobs);
    if (url.includes('api.github.com')) return w.dispatchStatus === 204 ? reply(null, 204) : reply({ message: 'nope' }, w.dispatchStatus);
    if (url.includes('/storage/v1/object/apks/')) return reply({ Key: 'ok' });
    throw new Error('unexpected fetch ' + url);
  }) as any;
  return { w, restore: () => (globalThis.fetch = original) };
}

function buildRequest(body: any, auth = 'Bearer user-token') {
  return new Request('https://worker.test/build', {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(auth ? { authorization: auth } : {}) },
    body: JSON.stringify(body),
  });
}

const goodBody = {
  zipUrl: 'https://proj.supabase.co/storage/v1/object/sign/uploads/u/p.zip?token=abc',
  appName: '  My   App ',
  versionName: '1.2.3',
  versionCode: 1780000000,
};

test('health reports whether it is configured', async () => {
  const res = await worker.fetch(new Request('https://worker.test/health'), env);
  assert.deepEqual(await res.json(), { ok: true, configured: true });
  const bare = await worker.fetch(new Request('https://worker.test/health'), {});
  assert.deepEqual(await bare.json(), { ok: true, configured: false });
});

test('rejects a build without a bearer token', async () => {
  const res = await worker.fetch(buildRequest(goodBody, ''), env);
  assert.equal(res.status, 401);
});

test('free plan: generated package, config cleaned, workflow dispatched', async () => {
  const { w, restore } = install();
  try {
    const res = await worker.fetch(
      buildRequest({
        ...goodBody,
        config: {
          orientation: 'landscape',
          primaryColor: '#2b44ff',
          minSdk: 26,
          permissions: ['CAMERA', 'CAMERA', 'SYSTEM_ALERT_WINDOW', 'INTERNET'],
          deepLinks: [
            { scheme: 'HTTPS', host: 'Example.com', pathPrefix: '/app' },
            { scheme: 'https', host: '', pathPrefix: '' },
            { scheme: 'ba d', host: 'x.com', pathPrefix: '' },
          ],
          iconUrl: 'https://evil.example/icon.png',
          unknownField: 'dropped',
        },
      }),
      env,
    );
    assert.equal(res.status, 200);
    const out: any = await res.json();
    assert.equal(out.jobId, JOB);
    assert.equal(out.packageId, 'com.ziphtml.u111111112222');

    const dispatch = w.calls.find((c) => c.url.includes('api.github.com'))!;
    assert.equal(dispatch.body.inputs.app_name, 'My App');
    assert.equal(dispatch.body.inputs.package_id, 'com.ziphtml.u111111112222');
    const cfg = JSON.parse(dispatch.body.inputs.build_config);
    assert.deepEqual(cfg, {
      orientation: 'landscape',
      primaryColor: '#2B44FF',
      minSdk: 26,
      permissions: ['CAMERA', 'INTERNET'],
      deepLinks: [{ scheme: 'https', host: 'example.com', pathPrefix: '/app' }],
    });
    assert.match(dispatch.body.inputs.callback_token, /^[0-9a-f]{64}$/);
  } finally {
    restore();
  }
});

test('a signed icon from our own bucket is kept', async () => {
  const { w, restore } = install({ plan: 'pro' });
  try {
    const iconUrl = 'https://proj.supabase.co/storage/v1/object/sign/uploads/u/r/icon.png?token=t';
    await worker.fetch(buildRequest({ ...goodBody, packageId: 'com.acme.notes', config: { iconUrl } }), env);
    const dispatch = w.calls.find((c) => c.url.includes('api.github.com'))!;
    assert.equal(JSON.parse(dispatch.body.inputs.build_config).iconUrl, iconUrl);
    assert.equal(dispatch.body.inputs.package_id, 'com.acme.notes');
  } finally {
    restore();
  }
});

test('free plan cannot pick a package name', async () => {
  const { restore } = install({ plan: 'free' });
  try {
    const res = await worker.fetch(buildRequest({ ...goodBody, packageId: 'com.acme.notes' }), env);
    assert.equal(res.status, 403);
    assert.equal(((await res.json()) as any).code, 'pro_only');
  } finally {
    restore();
  }
});

test('pro plan: reserved words and bad names are refused before any credit is touched', async () => {
  const { w, restore } = install({ plan: 'pro' });
  try {
    for (const bad of ['com.new.app', 'com.acme.class', 'nodots', 'com.1x.app', 'com.a-b.app']) {
      const res = await worker.fetch(buildRequest({ ...goodBody, packageId: bad }), env);
      assert.equal(res.status, 400, bad);
    }
    assert.equal(w.calls.some((c) => c.url.includes('consume_credit')), false);
  } finally {
    restore();
  }
});

test('source links must be public https', async () => {
  const { restore } = install();
  try {
    for (const zipUrl of ['http://example.com/a.zip', 'https://localhost/a.zip', 'https://192.168.1.5/a.zip', 'https://user:pw@example.com/a.zip', 'not a url', 'https://intranet/a.zip']) {
      const res = await worker.fetch(buildRequest({ ...goodBody, zipUrl }), env);
      assert.equal(res.status, 400, zipUrl);
    }
  } finally {
    restore();
  }
});

test('three open builds is the limit, and nothing is charged', async () => {
  const { w, restore } = install({ openJobs: 3 });
  try {
    const res = await worker.fetch(buildRequest(goodBody), env);
    assert.equal(res.status, 429);
    assert.equal(((await res.json()) as any).code, 'busy');
    assert.equal(w.calls.some((c) => c.url.includes('consume_credit')), false);
  } finally {
    restore();
  }
});

test('a failed GitHub dispatch fails the job and refunds the credit', async () => {
  const { w, restore } = install({ dispatchStatus: 422 });
  const quiet = console.error;
  console.error = () => {};
  try {
    const res = await worker.fetch(buildRequest(goodBody), env);
    assert.equal(res.status, 503);
    assert.equal(w.calls.some((c) => c.url.includes('refund_credit')), true);
    const patch = w.calls.find((c) => c.method === 'PATCH')!;
    assert.equal(patch.body.status, 'failed');
  } finally {
    console.error = quiet;
    restore();
  }
});

test('callback rejects a wrong token', async () => {
  const token = 'a'.repeat(64);
  const { restore } = install({ jobs: [{ id: JOB, user_id: USER, status: 'queued', charged: true, token_hash: createHash('sha256').update('b'.repeat(64)).digest('hex') }] });
  try {
    const res = await worker.fetch(new Request(`https://worker.test/callback/${JOB}`, { method: 'POST', headers: { 'content-type': 'application/json', 'x-job-token': token }, body: '{"status":"building"}' }), env);
    assert.equal(res.status, 401);
  } finally {
    restore();
  }
});

test('callback streams the APK to storage and marks the job done', async () => {
  const token = 'c'.repeat(64);
  const job = { id: JOB, user_id: USER, status: 'building', charged: true, token_hash: createHash('sha256').update(token).digest('hex') };
  const { w, restore } = install({ jobs: [job] });
  try {
    const apk = new Uint8Array(5000).fill(7);
    const res = await worker.fetch(
      new Request(`https://worker.test/callback/${JOB}`, {
        method: 'POST',
        headers: { 'content-type': 'application/vnd.android.package-archive', 'x-job-token': token, 'content-length': String(apk.length) },
        body: apk,
      }),
      env,
    );
    assert.equal(res.status, 200);
    const upload = w.calls.find((c) => c.url.includes('/storage/v1/object/apks/'))!;
    assert.ok(upload.url.endsWith(`${USER}/${JOB}.apk`));
    assert.equal(upload.headers['Content-Length'], '5000');
    assert.equal(typeof upload.body, 'object'); // a stream, not a buffered copy
    const patch = w.calls.find((c) => c.method === 'PATCH')!;
    assert.equal(patch.body.status, 'done');
    assert.equal(patch.body.apk_path, `${USER}/${JOB}.apk`);
  } finally {
    restore();
  }
});

test('callback fails the job when the APK is implausibly small', async () => {
  const token = 'd'.repeat(64);
  const job = { id: JOB, user_id: USER, status: 'building', charged: true, token_hash: createHash('sha256').update(token).digest('hex') };
  const { w, restore } = install({ jobs: [job] });
  try {
    const res = await worker.fetch(new Request(`https://worker.test/callback/${JOB}`, { method: 'POST', headers: { 'content-type': 'application/octet-stream', 'x-job-token': token, 'content-length': '10' }, body: new Uint8Array(10) }), env);
    assert.equal(res.status, 400);
    assert.equal(w.calls.some((c) => c.url.includes('refund_credit')), true);
  } finally {
    restore();
  }
});

test('the reaper fails stale builds and refunds charged ones only', async () => {
  const { w, restore } = install({ stale: [{ id: 'j1', user_id: USER, charged: true }, { id: 'j2', user_id: USER, charged: false }] });
  try {
    const failed = await reapStaleJobs(env);
    assert.equal(failed, 2);
    assert.equal(w.calls.filter((c) => c.url.includes('refund_credit')).length, 1);
  } finally {
    restore();
  }
});
