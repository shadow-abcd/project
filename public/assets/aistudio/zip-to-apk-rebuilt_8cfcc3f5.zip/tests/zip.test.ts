import assert from 'node:assert/strict';
import { deflateRawSync } from 'node:zlib';
import test from 'node:test';
import { inspectZip } from '../src/lib/zip.ts';

/* Tiny ZIP writer for tests: stored (0) or deflated (8) entries, no CRC checks needed by the reader. */
function makeZip(files: Record<string, string>, method: 0 | 8 = 0): Blob {
  const enc = new TextEncoder();
  const locals: Uint8Array[] = [];
  const centrals: Uint8Array[] = [];
  let offset = 0;
  for (const [name, text] of Object.entries(files)) {
    const nameBytes = enc.encode(name);
    const data = enc.encode(text);
    const body = method === 8 ? new Uint8Array(deflateRawSync(data)) : data;
    const local = new Uint8Array(30 + nameBytes.length + body.length);
    const lv = new DataView(local.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(8, method, true);
    lv.setUint32(18, body.length, true);
    lv.setUint32(22, data.length, true);
    lv.setUint16(26, nameBytes.length, true);
    local.set(nameBytes, 30);
    local.set(body, 30 + nameBytes.length);
    const central = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(central.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(10, method, true);
    cv.setUint32(20, body.length, true);
    cv.setUint32(24, data.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint32(42, offset, true);
    central.set(nameBytes, 46);
    locals.push(local);
    centrals.push(central);
    offset += local.length;
  }
  const cdSize = centrals.reduce((n, c) => n + c.length, 0);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, centrals.length, true);
  ev.setUint16(10, centrals.length, true);
  ev.setUint32(12, cdSize, true);
  ev.setUint32(16, offset, true);
  return new Blob([...locals, ...centrals, eocd] as BlobPart[]);
}

const PAGE = '<!doctype html><title>Pocket Notes</title><meta name="viewport" content="width=device-width">';

test('finds index.html and reads the page title', async () => {
  const r = await inspectZip(makeZip({ 'index.html': PAGE, 'app.js': '1' }));
  assert.equal(r.ok, true);
  assert.equal(r.indexPath, 'index.html');
  assert.equal(r.title, 'Pocket Notes');
  assert.equal(r.fileCount, 2);
  assert.deepEqual(r.errors, []);
  assert.deepEqual(r.warnings, []);
});

test('reads deflated entries too', async () => {
  const r = await inspectZip(makeZip({ 'index.html': PAGE }, 8));
  assert.equal(r.title, 'Pocket Notes');
});

test('uses the shallowest index.html and notes the folder', async () => {
  const r = await inspectZip(makeZip({ 'site/deep/index.html': PAGE, 'site/index.html': PAGE }));
  assert.equal(r.indexPath, 'site/index.html');
  assert.ok(r.notes.some((n) => n.includes('site/')));
});

test('reports a missing index.html', async () => {
  const r = await inspectZip(makeZip({ 'readme.txt': 'hi' }));
  assert.equal(r.ok, false);
  assert.match(r.errors[0], /No index\.html/);
});

test('points out a wrongly cased index file', async () => {
  const r = await inspectZip(makeZip({ 'Index.html': PAGE }));
  assert.equal(r.ok, false);
  assert.match(r.errors[0], /exactly index\.html/);
});

test('warns about node_modules and a missing viewport tag', async () => {
  const r = await inspectZip(makeZip({ 'index.html': '<title>x</title>', 'node_modules/a/b.js': '1' }));
  assert.equal(r.ok, true);
  assert.equal(r.warnings.length, 2);
});

test('detects a build script and manifest name', async () => {
  const r = await inspectZip(
    makeZip({ 'index.html': PAGE, 'package.json': '{"scripts":{"build":"vite build"}}', 'manifest.json': '{"name":"Notes PWA"}' }),
  );
  assert.equal(r.hasBuildScript, true);
  assert.equal(r.manifestName, 'Notes PWA');
});

test('ignores macOS metadata folders', async () => {
  const r = await inspectZip(makeZip({ '__MACOSX/._index.html': 'x', 'index.html': PAGE }));
  assert.equal(r.fileCount, 1);
});

test('rejects files that are not ZIP archives', async () => {
  const r = await inspectZip(new Blob(['this is plain text, definitely not a zip archive']));
  assert.equal(r.ok, false);
  assert.match(r.errors[0], /not a ZIP/);
});

test('rejects damaged archives', async () => {
  const r = await inspectZip(new Blob([new Uint8Array([0x50, 0x4b, 0x03, 0x04, ...new Array(60).fill(7)])]));
  assert.equal(r.ok, false);
  assert.match(r.errors[0], /damaged/);
});

test('rejects an empty archive', async () => {
  const r = await inspectZip(makeZip({}));
  assert.equal(r.ok, false);
});
