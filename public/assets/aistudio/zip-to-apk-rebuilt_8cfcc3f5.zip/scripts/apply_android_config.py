#!/usr/bin/env python3
"""Applies the options chosen in the web app to a Capacitor project.

    apply_android_config.py capacitor <shell_dir>   write capacitor.config.json (before `cap add`)
    apply_android_config.py android   <shell_dir>   patch the generated android/ project (after `cap sync`)

Reads BUILD_CONFIG (JSON), APP_NAME and PACKAGE_ID from the environment. Every value is validated
again here, because the workflow can also be started by hand. A missing or damaged option never
fails the build: it is reported as a warning and the default is kept.
"""
import json
import os
import re
import sys
from xml.sax.saxutils import escape, quoteattr

ALLOWED_PERMISSIONS = {
    'INTERNET', 'ACCESS_NETWORK_STATE', 'ACCESS_WIFI_STATE', 'NEARBY_WIFI_DEVICES', 'CAMERA', 'RECORD_AUDIO',
    'MODIFY_AUDIO_SETTINGS', 'VIBRATE', 'FLASHLIGHT', 'NFC', 'BLUETOOTH_CONNECT', 'BLUETOOTH_SCAN',
    'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'ACCESS_BACKGROUND_LOCATION', 'READ_MEDIA_IMAGES',
    'READ_MEDIA_VIDEO', 'READ_MEDIA_AUDIO', 'READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE', 'POST_NOTIFICATIONS',
    'WAKE_LOCK', 'RECEIVE_BOOT_COMPLETED', 'FOREGROUND_SERVICE', 'USE_BIOMETRIC', 'READ_CONTACTS', 'READ_CALENDAR',
    'CALL_PHONE',
}
# Legacy storage permissions are limited to the Android versions that still use them.
MAX_SDK = {'WRITE_EXTERNAL_STORAGE': 28, 'READ_EXTERNAL_STORAGE': 32}
ORIENTATION = {'portrait': 'portrait', 'landscape': 'landscape', 'sensor': 'fullSensor'}
HEX = re.compile(r'^#[0-9A-Fa-f]{6}$')


def warn(message):
    print('::warning::' + message)


def load_config(raw=None):
    raw = os.environ.get('BUILD_CONFIG', '') if raw is None else raw
    raw = raw.strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except ValueError:
        warn('build_config is not valid JSON, so default options are used.')
        return {}
    return data if isinstance(data, dict) else {}


def safe_label(name):
    """App name for capacitor.config.json: no characters that are special in XML or shell."""
    cleaned = re.sub(r'[&<>"\'\\\x00-\x1f\x7f]', '', name or '').strip()
    return cleaned[:40] or 'App'


def android_string(name):
    """Escape a display name for res/values/strings.xml (XML entities plus Android's own quoting)."""
    s = re.sub(r'[\x00-\x1f\x7f]', ' ', name or '').strip()[:40] or 'App'
    s = s.replace('\\', '\\\\')
    s = escape(s)
    s = s.replace('"', '\\"').replace("'", "\\'")
    if s[:1] in ('@', '?'):
        s = '\\' + s
    return s


# ---------------------------------------------------------------- capacitor.config.json

def build_capacitor_config(cfg, package_id, app_name):
    conf = {'appId': package_id, 'appName': safe_label(app_name), 'webDir': 'www'}
    color = cfg.get('primaryColor')
    if isinstance(color, str) and HEX.match(color):
        conf['backgroundColor'] = color.upper()
    android = {}
    if cfg.get('mixedContent') is True:
        android['allowMixedContent'] = True
    if cfg.get('webDebugging') is True:
        android['webContentsDebuggingEnabled'] = True
    if android:
        conf['android'] = android
    return conf


# ---------------------------------------------------------------- AndroidManifest.xml

def intent_filter(link):
    attrs = f'android:scheme={quoteattr(link["scheme"])}'
    if link.get('host'):
        attrs += f' android:host={quoteattr(link["host"])}'
    if link.get('pathPrefix'):
        attrs += f' android:pathPrefix={quoteattr(link["pathPrefix"])}'
    return (
        '        <intent-filter>\n'
        '            <action android:name="android.intent.action.VIEW" />\n'
        '            <category android:name="android.intent.category.DEFAULT" />\n'
        '            <category android:name="android.intent.category.BROWSABLE" />\n'
        f'            <data {attrs} />\n'
        '        </intent-filter>\n'
    )


def clean_links(raw):
    links = []
    for d in (raw if isinstance(raw, list) else [])[:5]:
        if not isinstance(d, dict):
            continue
        scheme = str(d.get('scheme', '')).strip().lower()
        host = str(d.get('host', '')).strip().lower()
        path = str(d.get('pathPrefix', '')).strip()
        if not re.fullmatch(r'[a-z][a-z0-9+.-]{0,30}', scheme):
            continue
        if not re.fullmatch(r'[a-z0-9*.-]{0,100}', host):
            continue
        if scheme in ('http', 'https') and not host:
            continue
        if path and not re.fullmatch(r"/[A-Za-z0-9._~!$&'()*+,;=:@%/-]{0,100}", path):
            continue
        links.append({'scheme': scheme, 'host': host, 'pathPrefix': path})
    return links


def patch_manifest(text, cfg):
    # Orientation, on the first <activity> (Capacitor's MainActivity).
    orientation = ORIENTATION.get(cfg.get('orientation'))
    if orientation:
        def set_orientation(m):
            tag = re.sub(r'\s+android:screenOrientation="[^"]*"', '', m.group(0))
            return tag.replace('<activity', f'<activity android:screenOrientation="{orientation}"', 1)
        text, n = re.subn(r'<activity\b[^>]*>', set_orientation, text, count=1)
        if not n:
            warn('Could not find <activity> to set the orientation.')

    # Permissions: add the ones asked for; drop INTERNET only if it was switched off on purpose.
    perms = cfg.get('permissions')
    if isinstance(perms, list):
        wanted = [p for p in dict.fromkeys(perms) if isinstance(p, str) and p in ALLOWED_PERMISSIONS]
        existing = set(re.findall(r'<uses-permission[^>]*android:name="android\.permission\.([A-Z0-9_]+)"', text))
        if 'INTERNET' not in wanted:
            text = re.sub(r'[ \t]*<uses-permission[^>]*android:name="android\.permission\.INTERNET"[^>]*/>[ \t]*\n?', '', text)
        lines = ''
        for p in wanted:
            if p in existing and p != 'INTERNET':
                continue
            if p == 'INTERNET' and 'INTERNET' in existing:
                continue
            extra = f' android:maxSdkVersion="{MAX_SDK[p]}"' if p in MAX_SDK else ''
            lines += f'    <uses-permission android:name="android.permission.{p}"{extra} />\n'
        if lines:
            text, n = re.subn(r'([ \t]*)<application\b', lambda m: lines + m.group(0), text, count=1)
            if not n:
                warn('Could not find <application>, so permissions were not added.')

    # Deep links: one intent filter each, so hosts and paths never combine across links.
    links = clean_links(cfg.get('deepLinks'))
    if links:
        block = ''.join(intent_filter(link) for link in links)
        text, n = re.subn(r'([ \t]*)</activity>', lambda m: block + m.group(0), text, count=1)
        if not n:
            warn('Could not find </activity>, so deep links were not added.')
    return text


# ---------------------------------------------------------------- other android files

def patch_strings(text, app_name):
    label = android_string(app_name)
    return re.sub(r'(<string name="(?:app_name|title_activity_main)">)[^<]*(</string>)', lambda m: m.group(1) + label + m.group(2), text)


def patch_styles(text, status_bar):
    if status_bar not in ('light', 'dark'):
        return text
    value = 'true' if status_bar == 'dark' else 'false'  # "dark" = dark icons on a light bar
    text = re.sub(r'\s*<item name="android:windowLightStatusBar">[^<]*</item>', '', text)
    pattern = re.compile(r'(<style\s+name="AppTheme\.NoActionBar"[^>]*>)')
    if not pattern.search(text):
        warn('Could not find the app theme, so the status bar style was not changed.')
        return text
    return pattern.sub(lambda m: m.group(1) + f'\n        <item name="android:windowLightStatusBar">{value}</item>', text, count=1)


def patch_min_sdk(text, requested):
    m = re.search(r'minSdkVersion\s*=\s*(\d+)', text)
    if not m:
        return text
    if requested <= int(m.group(1)):
        return text  # never go below what Capacitor itself needs
    return text[:m.start(1)] + str(requested) + text[m.end(1):]


def read(path):
    with open(path, encoding='utf-8') as f:
        return f.read()


def write(path, text):
    with open(path, 'w', encoding='utf-8') as f:
        f.write(text)


def apply_android(shell_dir, cfg, app_name):
    base = os.path.join(shell_dir, 'android')
    jobs = [
        ('app/src/main/AndroidManifest.xml', lambda t: patch_manifest(t, cfg)),
        ('app/src/main/res/values/strings.xml', lambda t: patch_strings(t, app_name)),
        ('app/src/main/res/values/styles.xml', lambda t: patch_styles(t, cfg.get('statusBar'))),
    ]
    if cfg.get('minSdk') in (24, 26, 28, 30):
        jobs.append(('variables.gradle', lambda t: patch_min_sdk(t, cfg['minSdk'])))
    for rel, fn in jobs:
        path = os.path.join(base, rel)
        if not os.path.exists(path):
            warn(f'{rel} was not found, so it was skipped.')
            continue
        before = read(path)
        after = fn(before)
        if after != before:
            write(path, after)
            print(f'Updated {rel}')


def main(argv):
    if len(argv) != 3 or argv[1] not in ('capacitor', 'android'):
        print(__doc__)
        return 2
    mode, shell_dir = argv[1], argv[2]
    cfg = load_config()
    app_name = os.environ.get('APP_NAME', 'App')
    if mode == 'capacitor':
        conf = build_capacitor_config(cfg, os.environ['PACKAGE_ID'], app_name)
        write(os.path.join(shell_dir, 'capacitor.config.json'), json.dumps(conf, indent=2) + '\n')
        print('Wrote capacitor.config.json')
    else:
        apply_android(shell_dir, cfg, app_name)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
