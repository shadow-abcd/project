import json
import os
import tempfile
import unittest
import xml.etree.ElementTree as ET

import apply_android_config as a

MANIFEST = '''<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:theme="@style/AppTheme">

        <activity
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode|navigation|density"
            android:name=".MainActivity"
            android:label="@string/title_activity_main"
            android:theme="@style/AppTheme.NoActionBarLaunch"
            android:launchMode="singleTask"
            android:exported="true">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

        </activity>

    </application>

    <!-- Permissions -->

    <uses-permission android:name="android.permission.INTERNET" />
</manifest>
'''

STRINGS = '''<?xml version='1.0' encoding='utf-8'?>
<resources>
    <string name="app_name">Old</string>
    <string name="title_activity_main">Old</string>
    <string name="package_name">com.x.y</string>
</resources>
'''

STYLES = '''<?xml version="1.0" encoding="utf-8" ?>
<resources>
    <style name="AppTheme" parent="Theme.AppCompat.DayNight" />
    <style name="AppTheme.NoActionBar" parent="Theme.AppCompat.DayNight.NoActionBar">
        <item name="windowActionBar">false</item>
    </style>
</resources>
'''

GRADLE = '''ext {
    minSdkVersion = 24
    compileSdkVersion = 36
}
'''


def parse(text):
    return ET.fromstring(text)  # raises if the XML is broken


class Manifest(unittest.TestCase):
    def test_orientation_permissions_and_links(self):
        cfg = {
            'orientation': 'landscape',
            'permissions': ['CAMERA', 'WRITE_EXTERNAL_STORAGE', 'SYSTEM_ALERT_WINDOW', 'INTERNET'],
            'deepLinks': [
                {'scheme': 'https', 'host': 'example.com', 'pathPrefix': '/app'},
                {'scheme': 'myapp', 'host': '', 'pathPrefix': ''},
            ],
        }
        out = a.patch_manifest(MANIFEST, cfg)
        parse(out)
        self.assertIn('android:screenOrientation="landscape"', out)
        self.assertIn('android.permission.CAMERA', out)
        self.assertIn('android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"', out)
        self.assertNotIn('SYSTEM_ALERT_WINDOW', out)
        self.assertEqual(out.count('android.permission.INTERNET'), 1)
        self.assertIn('android:host="example.com" android:pathPrefix="/app"', out)
        self.assertIn('android:scheme="myapp"', out)
        self.assertEqual(out.count('<intent-filter>'), 3)  # launcher plus two links
        self.assertLess(out.index('android.permission.CAMERA'), out.index('<application'))

    def test_internet_removed_only_when_switched_off(self):
        out = a.patch_manifest(MANIFEST, {'permissions': ['VIBRATE']})
        parse(out)
        self.assertNotIn('permission.INTERNET', out)
        self.assertIn('permission.VIBRATE', out)
        kept = a.patch_manifest(MANIFEST, {})  # no permissions key: template untouched
        self.assertIn('permission.INTERNET', kept)

    def test_is_idempotent_for_permissions(self):
        cfg = {'permissions': ['INTERNET', 'CAMERA']}
        once = a.patch_manifest(MANIFEST, cfg)
        twice = a.patch_manifest(once, cfg)
        self.assertEqual(twice.count('permission.CAMERA'), 1)
        self.assertEqual(twice.count('permission.INTERNET'), 1)

    def test_hostile_values_are_dropped_or_escaped(self):
        cfg = {
            'permissions': ['CAMERA" /><evil'],
            'deepLinks': [
                {'scheme': 'https', 'host': 'a.com"><x', 'pathPrefix': ''},
                {'scheme': 'https', 'host': 'ok.com', 'pathPrefix': '/a" b'},
                {'scheme': 'https', 'host': 'fine.com', 'pathPrefix': "/it's"},
            ],
        }
        out = a.patch_manifest(MANIFEST, cfg)
        parse(out)
        self.assertNotIn('evil', out)
        self.assertNotIn('a.com', out)
        self.assertNotIn('ok.com', out)
        self.assertIn('fine.com', out)

    def test_orientation_replaced_not_duplicated(self):
        once = a.patch_manifest(MANIFEST, {'orientation': 'portrait'})
        twice = a.patch_manifest(once, {'orientation': 'sensor'})
        self.assertEqual(twice.count('screenOrientation'), 1)
        self.assertIn('fullSensor', twice)


class Strings(unittest.TestCase):
    def test_labels_are_escaped_for_android(self):
        cases = {
            "Tom & Jerry": 'Tom &amp; Jerry',
            "Bob's App": "Bob\\'s App",
            'Say "hi"': 'Say \\"hi\\"',
            '<b>x</b>': '&lt;b&gt;x&lt;/b&gt;',
            '@home': '\\@home',
        }
        for name, expected in cases.items():
            self.assertEqual(a.android_string(name), expected, name)
            parse(a.patch_strings(STRINGS, name))  # still well-formed XML

    def test_both_label_strings_replaced(self):
        out = a.patch_strings(STRINGS, 'New Name')
        self.assertEqual(out.count('New Name'), 2)
        self.assertIn('com.x.y', out)

    def test_capacitor_label_has_no_special_characters(self):
        self.assertEqual(a.safe_label('Tom & "Jerry" <3'), 'Tom  Jerry 3')
        self.assertEqual(a.safe_label('&&&'), 'App')


class Other(unittest.TestCase):
    def test_status_bar(self):
        dark = a.patch_styles(STYLES, 'dark')
        parse(dark)
        self.assertIn('windowLightStatusBar">true', dark)
        light = a.patch_styles(dark, 'light')
        self.assertEqual(light.count('windowLightStatusBar'), 1)
        self.assertIn('windowLightStatusBar">false', light)
        self.assertEqual(a.patch_styles(STYLES, 'default'), STYLES)

    def test_min_sdk_never_goes_down(self):
        self.assertIn('minSdkVersion = 28', a.patch_min_sdk(GRADLE, 28))
        self.assertIn('minSdkVersion = 24', a.patch_min_sdk(GRADLE, 24))
        self.assertIn('minSdkVersion = 26', a.patch_min_sdk(GRADLE.replace('minSdkVersion = 24', 'minSdkVersion = 26'), 24))

    def test_capacitor_config(self):
        conf = a.build_capacitor_config({'primaryColor': '#2b44ff', 'webDebugging': True, 'mixedContent': False}, 'com.a.b', 'My App')
        self.assertEqual(conf['backgroundColor'], '#2B44FF')
        self.assertEqual(conf['android'], {'webContentsDebuggingEnabled': True})
        self.assertEqual(conf['appId'], 'com.a.b')
        plain = a.build_capacitor_config({'primaryColor': 'red'}, 'com.a.b', 'X')
        self.assertNotIn('backgroundColor', plain)
        self.assertNotIn('android', plain)

    def test_bad_json_is_survivable(self):
        self.assertEqual(a.load_config('{not json'), {})
        self.assertEqual(a.load_config('[1,2]'), {})
        self.assertEqual(a.load_config(''), {})


class EndToEnd(unittest.TestCase):
    def test_android_phase_on_a_project_folder(self):
        with tempfile.TemporaryDirectory() as d:
            res = os.path.join(d, 'android/app/src/main/res/values')
            os.makedirs(res)
            for rel, content in {
                'android/app/src/main/AndroidManifest.xml': MANIFEST,
                'android/app/src/main/res/values/strings.xml': STRINGS,
                'android/app/src/main/res/values/styles.xml': STYLES,
                'android/variables.gradle': GRADLE,
            }.items():
                with open(os.path.join(d, rel), 'w') as f:
                    f.write(content)
            cfg = {'orientation': 'portrait', 'statusBar': 'dark', 'minSdk': 28, 'permissions': ['CAMERA', 'INTERNET']}
            a.apply_android(d, cfg, "Bob's Notes")
            parse(a.read(os.path.join(d, 'android/app/src/main/AndroidManifest.xml')))
            parse(a.read(os.path.join(d, 'android/app/src/main/res/values/strings.xml')))
            parse(a.read(os.path.join(d, 'android/app/src/main/res/values/styles.xml')))
            self.assertIn("Bob\\'s Notes", a.read(os.path.join(d, 'android/app/src/main/res/values/strings.xml')))
            self.assertIn('minSdkVersion = 28', a.read(os.path.join(d, 'android/variables.gradle')))

    def test_missing_files_only_warn(self):
        with tempfile.TemporaryDirectory() as d:
            a.apply_android(d, {'orientation': 'portrait', 'minSdk': 28}, 'X')  # must not raise


if __name__ == '__main__':
    unittest.main()
