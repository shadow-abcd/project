/* Regenerates every icon, splash screen and banner from the SVG definitions below.
   Usage:  npm i --no-save sharp && node scripts/generate-icons.mjs
   Output: public/icons/*, public/favicon.svg, assets/* (for @capacitor/assets), docs/banner.png */
import sharp from 'sharp';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = (p) => join(root, p);
for (const d of ['public/icons', 'assets', 'docs']) mkdirSync(out(d), { recursive: true });

const COBALT = '#2B44FF';
const COBALT_DEEP = '#1626C4';
const TAPE = '#FFC72C';
const INK = '#0D1030';
const PAPER = '#F5F6FA';

/* The mark: a zip archive. White sheet, interlocked zipper teeth, yellow pull tab.
   Everything sits inside Android's 66% adaptive-icon safe zone. */
function mark() {
  let teeth = '';
  for (let i = 0; i < 9; i++) {
    const y = 296 + i * 36;
    teeth += `<rect x="486" y="${y}" width="26" height="20" rx="4" fill="${COBALT}"/>`;
    teeth += `<rect x="512" y="${y + 18}" width="26" height="20" rx="4" fill="${COBALT_DEEP}"/>`;
  }
  return `
    <rect x="332" y="282" width="360" height="500" rx="48" fill="#0A1070" opacity=".28"/>
    <rect x="332" y="262" width="360" height="500" rx="48" fill="#FFFFFF"/>
    ${teeth}
    <rect x="476" y="600" width="72" height="68" rx="18" fill="${TAPE}"/>
    <rect x="490" y="650" width="44" height="96" rx="22" fill="${TAPE}"/>
    <circle cx="512" cy="704" r="11" fill="#FFFFFF"/>`;
}

const gradDefs = `<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
  <stop offset="0" stop-color="#4A63FF"/><stop offset="1" stop-color="${COBALT_DEEP}"/></linearGradient></defs>`;

const svg = (inner, size = 1024) =>
  Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 1024 1024">${inner}</svg>`);

const full = svg(`${gradDefs}<rect width="1024" height="1024" fill="url(#g)"/>${mark()}`);
const rounded = svg(`${gradDefs}<rect width="1024" height="1024" rx="228" fill="url(#g)"/>${mark()}`);
const fg = svg(mark());
const bg = svg(`${gradDefs}<rect width="1024" height="1024" fill="url(#g)"/>`);

const png = (buf, size, file) => sharp(buf).resize(size, size).png({ compressionLevel: 9 }).toFile(out(file));

await png(rounded, 192, 'public/icons/icon-192.png');
await png(rounded, 512, 'public/icons/icon-512.png');
await png(full, 512, 'public/icons/icon-maskable-512.png');
await png(rounded, 180, 'public/icons/apple-touch-icon.png');
await png(rounded, 32, 'public/icons/favicon-32.png');
await png(full, 1024, 'assets/icon-only.png');
await png(fg, 1024, 'assets/icon-foreground.png');
await png(bg, 1024, 'assets/icon-background.png');

writeFileSync(
  out('public/favicon.svg'),
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024">${gradDefs}<rect width="1024" height="1024" rx="228" fill="url(#g)"/>${mark()}</svg>\n`,
);

/* Splash screens: the icon centred on a flat field */
async function splash(color, file) {
  const icon = await sharp(rounded).resize(640, 640).png().toBuffer();
  await sharp({ create: { width: 2732, height: 2732, channels: 4, background: color } })
    .composite([{ input: icon, gravity: 'center' }])
    .png({ compressionLevel: 9 })
    .toFile(out(file));
}
await splash(PAPER, 'assets/splash.png');
await splash(INK, 'assets/splash-dark.png');

/* README banner */
const banner = Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="640" viewBox="0 0 1280 640">
  <rect width="1280" height="640" fill="${INK}"/>
  <g transform="translate(96 150) scale(.34)">${gradDefs}<rect width="1024" height="1024" rx="228" fill="url(#g)"/>${mark()}</g>
  <text x="96" y="430" font-family="Helvetica, Arial, DejaVu Sans, sans-serif" font-size="76" font-weight="700" fill="#EEF0FF">Zip &amp; HTML to APK</text>
  <text x="96" y="492" font-family="Helvetica, Arial, DejaVu Sans, sans-serif" font-size="34" fill="#9AA3D6">Turn a zipped web project into an installable Android app.</text>
  ${Array.from({ length: 34 }, (_, i) => `<rect x="${620 + i * 18}" y="${i % 2 ? 130 : 118}" width="10" height="14" rx="3" fill="${i < 22 ? TAPE : '#2C336E'}"/>`).join('')}
</svg>`);
await sharp(banner).png().toFile(out('docs/banner.png'));

console.log('Icons, splash screens and banner written.');
