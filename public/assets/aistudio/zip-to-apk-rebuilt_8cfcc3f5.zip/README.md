<p align="center"><img src="docs/banner.png" alt="Zip to APK" width="720"></p>

# Zip to APK

Turn a zipped web project, or a single HTML file, into an installable Android app. People sign in, upload a file, choose a name, icon and permissions, and get an APK back a few minutes later. No Android Studio needed.

```
App (React, runs on the web and inside the Android app)
  -> Supabase  (sign-in, credits, file storage, build history)
  -> Cloudflare Worker  (checks the plan, charges a credit, starts the build)
  -> GitHub Actions  (builds the APK with Capacitor and Gradle, sends it back)
```

## What it does

- Checks the ZIP in the browser before upload and says what is wrong (no `index.html`, wrong file name, missing viewport tag).
- Builds from an uploaded file or a public link.
- Applies the options you choose: name, version, icon, theme color, orientation, status bar, 28 permissions, deep links, minimum Android version, WebView options.
- Free plan: a build costs one credit, earned by watching ads. Pro and Developer plans are unlimited and can choose their own package name.
- Fails safely: a build that dies without reporting is closed after 45 minutes and its credit is returned.

## Run it locally

```bash
npm install
cp .env.example .env.local     # then fill it in
npm run dev
npm test                       # unit tests: helpers, Worker, Android config script
npm run typecheck
```

## Set it up (one time)

1. **Supabase.** Create a project. In the SQL editor run `supabase/setup.sql`, then `migration_v2.sql`, then `storage.sql` (see `supabase/README.md`). Optionally turn off "Confirm email" while testing.
2. **GitHub.** Push this repo. Under *Settings > Secrets and variables > Actions > Variables* add `WORKER_URL` (next step gives you the value). Optional: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `ADMOB_APP_ID`, `ADMOB_TESTING`.
3. **Worker.** In `worker/`, set `GITHUB_REPO` in `wrangler.toml`, run `npx wrangler deploy`, then `npx wrangler secret put SUPABASE_SERVICE_ROLE_KEY` and `npx wrangler secret put GITHUB_TOKEN` (a fine-grained token with *Actions: read and write* on this repo only). Deploying through the Cloudflare dashboard instead? Paste `worker.js`, add the same variables and secrets, and add a **Cron Trigger** of `*/10 * * * *`. Copy the Worker's URL into the `WORKER_URL` variable from step 2.
4. **Build the app.** Push to `main` (or run *Build APKs* by hand). The workflow publishes `zip-to-apk-debug-apk` as an artifact. For the web version deploy `dist/` to Netlify or Vercel (`netlify.toml` and `vercel.json` are included) with `VITE_WORKER_URL` set.
5. **Check it.** Open `https://<your-worker>/health`. It should answer `{"ok":true,"configured":true}`.

## Troubleshooting

- **The APK still shows the old app name or package name.** An old `android/` folder or an old zip in the repository is being built. See `docs/UPGRADING.md`, the first section.
- **Blank screen.** After 8 seconds the app shows an error with the file or message that failed. If you see the sign-in screen, open Settings and run *Connection check*.
- **The Build button is off.** `WORKER_URL` is not set in GitHub, or the Worker is missing its secrets. *Connection check* names which.
- **A build fails on GitHub.** Open the failed step in the run. The first red line is the cause, and the run summary has a plain-language hint.

## Project layout

```
src/                  the app (React + TypeScript, plain CSS design system in src/styles)
  pages/build/        the four-step build wizard
  services/           cloud builds, ads, account
  lib/                ZIP inspector, package-name rules, store, router
worker/               Cloudflare Worker (build service)
scripts/              Android option patcher + its tests, icon generator
supabase/             database scripts
assets/               icon and splash sources for @capacitor/assets
.github/workflows/    build.yml (APK builds) and ci.yml (checks)
```

Regenerate every icon and splash screen with `npm i --no-save sharp && node scripts/generate-icons.mjs`.

## Good to know

- **Ads on the web.** AdMob only exists in the Android app. On the web a clearly labelled demo ad lets people earn credits. Set `VITE_WEB_DEMO_ADS=false` to turn that off.
- **Debug builds.** Output is a debug-signed APK, fine for sharing and testing. Signed release APKs and Play Store bundles (AAB) are not built yet.
- **Package names.** Free builds get `com.ziphtml.u<id>`. Pro names must follow Android rules, and Java words such as `new` or `class` are refused.
- **Only convert projects you own** or have permission to use.
