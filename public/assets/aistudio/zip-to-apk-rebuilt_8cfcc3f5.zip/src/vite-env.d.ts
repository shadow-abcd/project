/// <reference types="vite/client" />

declare const __APP_VERSION__: string;

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_ANON_KEY?: string;
  readonly VITE_WORKER_URL?: string;
  readonly VITE_ADMOB_TESTING?: string;
  readonly VITE_WEB_DEMO_ADS?: string;
  readonly VITE_ADMOB_APP_ID?: string;
  readonly VITE_ADMOB_BANNER?: string;
  readonly VITE_ADMOB_INTERSTITIAL?: string;
  readonly VITE_ADMOB_REWARDED?: string;
}

interface Window {
  __zipapkBoot?: { mounted: boolean; errors: string[] };
}
