import type { Permission } from '@/types';

/* The permissions a web app can sensibly ask for. The build Worker keeps its own copy of the
   allowed names (worker/worker.js), so a hand-made request cannot add anything else. */
export const PERMISSIONS: Permission[] = [
  { android: 'INTERNET', name: 'Internet', description: 'Load web content over the network', dangerous: false, category: 'Network' },
  { android: 'ACCESS_NETWORK_STATE', name: 'Network state', description: 'Check whether the device is online', dangerous: false, category: 'Network' },
  { android: 'ACCESS_WIFI_STATE', name: 'Wi-Fi state', description: 'See Wi-Fi connection status', dangerous: false, category: 'Network' },
  { android: 'NEARBY_WIFI_DEVICES', name: 'Nearby Wi-Fi devices', description: 'Find and connect to nearby Wi-Fi devices (Android 13+)', dangerous: true, category: 'Network' },
  { android: 'CAMERA', name: 'Camera', description: 'Take photos and video from your pages', dangerous: true, category: 'Hardware' },
  { android: 'RECORD_AUDIO', name: 'Microphone', description: 'Record audio from your pages', dangerous: true, category: 'Hardware' },
  { android: 'MODIFY_AUDIO_SETTINGS', name: 'Audio settings', description: 'Change volume and audio routing', dangerous: false, category: 'Hardware' },
  { android: 'VIBRATE', name: 'Vibrate', description: 'Vibration feedback', dangerous: false, category: 'Hardware' },
  { android: 'FLASHLIGHT', name: 'Flashlight', description: 'Control the camera torch', dangerous: false, category: 'Hardware' },
  { android: 'NFC', name: 'NFC', description: 'Read and write NFC tags', dangerous: false, category: 'Hardware' },
  { android: 'BLUETOOTH_CONNECT', name: 'Bluetooth connect', description: 'Connect to paired Bluetooth devices (Android 12+)', dangerous: true, category: 'Hardware' },
  { android: 'BLUETOOTH_SCAN', name: 'Bluetooth scan', description: 'Discover nearby Bluetooth devices (Android 12+)', dangerous: true, category: 'Hardware' },
  { android: 'ACCESS_FINE_LOCATION', name: 'Precise location', description: 'GPS location', dangerous: true, category: 'Location' },
  { android: 'ACCESS_COARSE_LOCATION', name: 'Approximate location', description: 'Location to within a few kilometres', dangerous: true, category: 'Location' },
  { android: 'ACCESS_BACKGROUND_LOCATION', name: 'Background location', description: 'Location while the app is closed. Google Play reviews this closely', dangerous: true, category: 'Location' },
  { android: 'READ_MEDIA_IMAGES', name: 'Photos', description: 'Read photos (Android 13+)', dangerous: true, category: 'Storage' },
  { android: 'READ_MEDIA_VIDEO', name: 'Videos', description: 'Read videos (Android 13+)', dangerous: true, category: 'Storage' },
  { android: 'READ_MEDIA_AUDIO', name: 'Music and audio', description: 'Read audio files (Android 13+)', dangerous: true, category: 'Storage' },
  { android: 'READ_EXTERNAL_STORAGE', name: 'Read storage', description: 'Read files on Android 12 and older', dangerous: true, category: 'Storage' },
  { android: 'WRITE_EXTERNAL_STORAGE', name: 'Write storage', description: 'Save files on Android 9 and older', dangerous: true, category: 'Storage' },
  { android: 'POST_NOTIFICATIONS', name: 'Notifications', description: 'Show notifications (Android 13+)', dangerous: true, category: 'System' },
  { android: 'WAKE_LOCK', name: 'Keep awake', description: 'Keep the screen on while the app is open', dangerous: false, category: 'System' },
  { android: 'RECEIVE_BOOT_COMPLETED', name: 'Run at startup', description: 'Be notified when the device boots', dangerous: false, category: 'System' },
  { android: 'FOREGROUND_SERVICE', name: 'Foreground service', description: 'Run long tasks with a notification', dangerous: false, category: 'System' },
  { android: 'USE_BIOMETRIC', name: 'Biometrics', description: 'Fingerprint or face authentication', dangerous: false, category: 'Security' },
  { android: 'READ_CONTACTS', name: 'Read contacts', description: 'Read the address book', dangerous: true, category: 'Personal data' },
  { android: 'READ_CALENDAR', name: 'Read calendar', description: 'Read calendar events', dangerous: true, category: 'Personal data' },
  { android: 'CALL_PHONE', name: 'Make phone calls', description: 'Start calls directly', dangerous: true, category: 'Personal data' },
];

export const DEFAULT_PERMISSIONS: string[] = ['INTERNET', 'ACCESS_NETWORK_STATE'];

/** Permissions Google Play asks you to justify in a declaration form. */
export const PLAY_RESTRICTED: string[] = ['ACCESS_BACKGROUND_LOCATION', 'READ_CONTACTS', 'CALL_PHONE', 'READ_CALENDAR'];

export const PERMISSION_CATEGORIES: string[] = [...new Set(PERMISSIONS.map((p) => p.category))];
