/* Turns raw errors (Postgres, Supabase, the Worker, the network) into one plain sentence. */

const RULES: Array<[RegExp, string]> = [
  [/rate_limited/, 'Please wait a few seconds before watching another ad.'],
  [/daily_limit/, 'Daily ad limit reached. Try again tomorrow.'],
  [/not_needed/, 'Pro and Developer accounts do not need ads.'],
  [/no_credits/, 'You have no build credits. Watch two ads to earn one.'],
  [/not_authenticated|Please sign in|JWT expired|invalid.*token/i, 'Your session has expired. Sign in again.'],
  [/ad_unavailable/, 'No ad is available right now. Try again in a minute.'],
  [/no_profile/, 'Your profile is missing. Run supabase/setup.sql in your Supabase project.'],
  [/ad_progress|column .* does not exist/, 'The database is out of date. Run supabase/migration_v2.sql in Supabase.'],
  [/Invalid login credentials/i, 'Wrong email or password.'],
  [/Email not confirmed/i, 'Confirm your email first. Check your inbox for the link.'],
  [/already registered|already been registered/i, 'That email already has an account. Try signing in.'],
  [/Password should be at least/i, 'Use a password with at least 6 characters.'],
  [/rate limit|too many requests|over_email_send_rate_limit/i, 'Too many attempts. Wait a minute and try again.'],
  [/Failed to fetch|NetworkError|Load failed|network request failed/i, 'Network error. Check your connection and try again.'],
  [/exceeded the maximum allowed size|Payload too large|entity too large/i, 'That file is too large to upload (50 MB maximum).'],
  [/Bucket not found/i, 'The storage buckets are missing. Run supabase/migration_v2.sql in Supabase.'],
  [/row-level security|violates row-level/i, 'The server refused the upload. Sign in again and retry.'],
];

export function errorText(err: unknown): string {
  if (typeof err === 'string') return err;
  if (err && typeof err === 'object') {
    const e = err as { message?: unknown; error_description?: unknown; error?: unknown };
    for (const v of [e.message, e.error_description, e.error]) if (typeof v === 'string' && v) return v;
  }
  return 'Something went wrong.';
}

export function friendlyError(err: unknown): string {
  const raw = errorText(err);
  for (const [re, message] of RULES) if (re.test(raw)) return message;
  return raw.length > 220 ? `${raw.slice(0, 217)}...` : raw;
}
