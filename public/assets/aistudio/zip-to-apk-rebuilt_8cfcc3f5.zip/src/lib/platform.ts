import { Capacitor } from '@capacitor/core';

/** True inside the installed Android app, false in a browser. */
export const isNative: boolean = Capacitor.isNativePlatform();

export function openExternal(url: string): void {
  if (isNative) window.open(url, '_system');
  else window.open(url, '_blank', 'noopener,noreferrer');
}
