import { useSyncExternalStore } from 'react';

export type ToastKind = 'info' | 'success' | 'error';
export interface ToastItem {
  id: number;
  kind: ToastKind;
  message: string;
}

let items: ToastItem[] = [];
let nextId = 1;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

export function dismissToast(id: number): void {
  items = items.filter((t) => t.id !== id);
  emit();
}

export function toast(message: string, kind: ToastKind = 'info'): void {
  const id = nextId++;
  items = [...items.slice(-2), { id, kind, message }]; // keep at most three on screen
  emit();
  window.setTimeout(() => dismissToast(id), kind === 'error' ? 6000 : 4000);
}

export function useToasts(): ToastItem[] {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => items,
    () => items,
  );
}
