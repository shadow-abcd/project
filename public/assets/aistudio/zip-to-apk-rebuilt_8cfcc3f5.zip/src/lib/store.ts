/* Local project storage. Versioned key, validated on read, and tolerant of a full disk. */

import { STORAGE_PREFIX } from '@/config/brand';
import type { Project } from '@/types';
import { uid } from './format';

const KEY = `${STORAGE_PREFIX}:v1:projects`;
const EVENT = `${STORAGE_PREFIX}:projects-changed`;
const MAX_BUILD_RECORDS = 20;

function isProject(value: unknown): value is Project {
  if (!value || typeof value !== 'object') return false;
  const p = value as Partial<Project>;
  return typeof p.id === 'string' && typeof p.name === 'string' && !!p.settings && typeof p.settings === 'object' && !!p.source;
}

function read(): Project[] {
  try {
    const raw = localStorage.getItem(KEY);
    const data: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(data) ? data.filter(isProject) : [];
  } catch {
    return [];
  }
}

function write(list: Project[]): boolean {
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
    window.dispatchEvent(new Event(EVENT));
    return true;
  } catch {
    return false;
  }
}

export function subscribeProjects(listener: () => void): () => void {
  window.addEventListener(EVENT, listener);
  window.addEventListener('storage', listener); // other tabs
  return () => {
    window.removeEventListener(EVENT, listener);
    window.removeEventListener('storage', listener);
  };
}

export function listProjects(): Project[] {
  return read().sort((a, b) => b.updatedAt - a.updatedAt);
}

export function getProject(id: string): Project | undefined {
  return read().find((p) => p.id === id);
}

export type SaveResult = 'ok' | 'saved-without-logo' | 'failed';

/** Saves a project. If the disk is full it retries without the icon image before giving up. */
export function saveProject(project: Project): SaveResult {
  const next: Project = {
    ...project,
    updatedAt: Date.now(),
    builds: project.builds.slice(-MAX_BUILD_RECORDS),
  };
  const list = read();
  const i = list.findIndex((p) => p.id === next.id);
  if (i >= 0) list[i] = next;
  else list.unshift(next);

  if (write(list)) return 'ok';

  const lean = list.map((p) => ({ ...p, settings: { ...p.settings, logoDataUrl: undefined } }));
  return write(lean) ? 'saved-without-logo' : 'failed';
}

export function deleteProject(id: string): void {
  write(read().filter((p) => p.id !== id));
}

export function setProjectStatus(id: string, status: Project['status']): void {
  const p = getProject(id);
  if (p) saveProject({ ...p, status });
}

export function duplicateProject(id: string): Project | undefined {
  const original = getProject(id);
  if (!original) return undefined;
  const now = Date.now();
  const copy: Project = {
    ...(JSON.parse(JSON.stringify(original)) as Project),
    id: uid(),
    name: `${original.name} copy`,
    status: 'draft',
    createdAt: now,
    updatedAt: now,
    builds: [],
  };
  saveProject(copy);
  return copy;
}

export function clearProjects(): void {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* nothing to clear */
  }
  window.dispatchEvent(new Event(EVENT));
}

export function exportProjects(): string {
  return JSON.stringify({ app: 'zip-to-apk', version: 1, exportedAt: new Date().toISOString(), projects: read() }, null, 2);
}

/** Merges projects from an export file. Returns how many were added. */
export function importProjects(text: string): number {
  let data: unknown;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('That file is not valid JSON.');
  }
  const incoming = (data as { projects?: unknown })?.projects;
  if (!Array.isArray(incoming)) throw new Error('That file does not contain any projects.');
  const list = read();
  const known = new Set(list.map((p) => p.id));
  let added = 0;
  for (const item of incoming) {
    if (!isProject(item) || known.has(item.id)) continue;
    list.push({ ...item, status: item.status === 'building' ? 'draft' : item.status });
    added++;
  }
  if (added > 0 && !write(list)) throw new Error('There is not enough storage space for these projects.');
  return added;
}

export function projectStats() {
  const list = read();
  const builds = list.flatMap((p) => p.builds);
  return {
    projects: list.length,
    builds: builds.length,
    succeeded: builds.filter((b) => b.status === 'completed').length,
    failed: builds.filter((b) => b.status === 'failed').length,
  };
}
