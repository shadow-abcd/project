/* Validation helpers for Android application ids, version names and app labels.
   Pure functions with no imports, so they run unchanged in the browser and in Node tests. */

// Words the Java compiler reserves. Android rejects a package segment that uses one.
export const JAVA_KEYWORDS: ReadonlySet<string> = new Set([
  'abstract', 'assert', 'boolean', 'break', 'byte', 'case', 'catch', 'char', 'class', 'const',
  'continue', 'default', 'do', 'double', 'else', 'enum', 'extends', 'final', 'finally', 'float',
  'for', 'goto', 'if', 'implements', 'import', 'instanceof', 'int', 'interface', 'long', 'native',
  'new', 'package', 'private', 'protected', 'public', 'return', 'short', 'static', 'strictfp',
  'super', 'switch', 'synchronized', 'this', 'throw', 'throws', 'transient', 'try', 'void',
  'volatile', 'while', 'true', 'false', 'null', '_',
]);

export const PACKAGE_RE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
export const VERSION_RE = /^[0-9A-Za-z._-]{1,20}$/;
export const APP_NAME_MAX = 30;

export function normalizePackageId(value: string): string {
  return value.trim().toLowerCase();
}

/** Returns a message describing the first problem, or null when the id is valid. */
export function validatePackageId(value: string): string | null {
  const id = normalizePackageId(value);
  if (!id) return 'Enter a package name, for example com.yourname.app.';
  if (id.length > 100) return 'The package name is too long. Use 100 characters or fewer.';
  if (!PACKAGE_RE.test(id)) {
    return 'Use at least two parts separated by dots. Each part starts with a letter and may contain letters, numbers and underscores.';
  }
  const reserved = id.split('.').find((part) => JAVA_KEYWORDS.has(part));
  if (reserved) return `"${reserved}" is a reserved word, so it cannot be part of a package name.`;
  return null;
}

/** Non-blocking advice about a valid id. */
export function packageWarning(value: string): string | null {
  const id = normalizePackageId(value);
  if (id.startsWith('com.example.') || id === 'com.example') {
    return 'Google Play rejects ids that start with com.example. Pick your own name before you publish.';
  }
  if (id.startsWith('com.android.') || id.startsWith('android.')) {
    return 'Ids that start with android are reserved by the system.';
  }
  return null;
}

export function suggestPackageId(appName: string): string {
  let slug = appName
    .normalize('NFKD')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .slice(0, 20);
  if (!slug) slug = 'myapp';
  if (/^[0-9]/.test(slug)) slug = `app${slug}`;
  if (JAVA_KEYWORDS.has(slug)) slug = `${slug}app`;
  return `com.${slug}.app`;
}

export function validateVersionName(value: string): string | null {
  const v = value.trim();
  if (!v) return 'Enter a version, for example 1.0.0.';
  if (!VERSION_RE.test(v)) return 'Use letters, numbers, dots, dashes and underscores (20 characters max).';
  return null;
}

/** Collapses whitespace and strips control characters. The cloud build escapes the rest. */
export function sanitizeAppName(value: string): string {
  // eslint-disable-next-line no-control-regex
  return value.replace(/[\u0000-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim().slice(0, APP_NAME_MAX);
}

export function slugify(value: string, fallback = 'app'): string {
  const s = value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return s || fallback;
}
