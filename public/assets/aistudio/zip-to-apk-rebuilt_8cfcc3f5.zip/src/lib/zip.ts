/* Reads a ZIP's table of contents in the browser, before anything is uploaded.
   It catches the most common cause of failed builds (no index.html) while the user is
   still looking at the file. Only the central directory and, optionally, a few small
   entries are read, so even a 50 MB archive is inspected in milliseconds.
   Pure browser/Node 18+ APIs, no dependencies. */

export interface ZipReport {
  /** True when the archive has a usable index.html. */
  ok: boolean;
  fileCount: number;
  totalBytes: number;
  indexPath: string | null;
  title?: string;
  manifestName?: string;
  hasBuildScript: boolean;
  errors: string[];
  warnings: string[];
  notes: string[];
  /** The directory listing could not be read (for example ZIP64). The cloud build still tries. */
  unreadable: boolean;
}

interface Entry {
  name: string;
  flags: number;
  method: number;
  compSize: number;
  size: number;
  offset: number;
}

const SIG_EOCD = 0x06054b50;
const SIG_CEN = 0x02014b50;
const SIG_LOC = 0x04034b50;
const MAX_ENTRIES = 200_000;
const MAX_TEXT_BYTES = 256 * 1024;

function emptyReport(): ZipReport {
  return {
    ok: false,
    fileCount: 0,
    totalBytes: 0,
    indexPath: null,
    hasBuildScript: false,
    errors: [],
    warnings: [],
    notes: [],
    unreadable: false,
  };
}

function depth(path: string): number {
  return path.split('/').filter(Boolean).length;
}

function isJunk(path: string): boolean {
  return path.startsWith('__MACOSX/') || path.includes('/__MACOSX/') || path.endsWith('.DS_Store');
}

async function inflateRaw(data: Uint8Array, maxBytes: number): Promise<Uint8Array | null> {
  if (typeof DecompressionStream === 'undefined') return null;
  const stream = new Blob([data as BlobPart]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  const reader = stream.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
    total += value.length;
    if (total >= maxBytes) {
      await reader.cancel();
      break;
    }
  }
  const out = new Uint8Array(Math.min(total, maxBytes));
  let pos = 0;
  for (const chunk of chunks) {
    const room = out.length - pos;
    if (room <= 0) break;
    const part = chunk.length > room ? chunk.subarray(0, room) : chunk;
    out.set(part, pos);
    pos += part.length;
  }
  return out;
}

async function readEntryText(file: Blob, entry: Entry): Promise<string | null> {
  try {
    if (entry.flags & 1) return null; // encrypted
    const head = new DataView(await file.slice(entry.offset, entry.offset + 30).arrayBuffer());
    if (head.byteLength < 30 || head.getUint32(0, true) !== SIG_LOC) return null;
    const start = entry.offset + 30 + head.getUint16(26, true) + head.getUint16(28, true);
    if (entry.compSize > 8 * 1024 * 1024) return null;
    const raw = new Uint8Array(await file.slice(start, start + entry.compSize).arrayBuffer());
    let bytes: Uint8Array | null;
    if (entry.method === 0) bytes = raw.subarray(0, MAX_TEXT_BYTES);
    else if (entry.method === 8) bytes = await inflateRaw(raw, MAX_TEXT_BYTES);
    else bytes = null;
    return bytes ? new TextDecoder('utf-8').decode(bytes) : null;
  } catch {
    return null;
  }
}

async function readDirectory(file: Blob): Promise<Entry[] | 'zip64' | null> {
  const tailLen = Math.min(file.size, 22 + 0xffff);
  const tail = new DataView(await file.slice(file.size - tailLen).arrayBuffer());
  let at = -1;
  for (let i = tail.byteLength - 22; i >= 0; i--) {
    if (tail.getUint32(i, true) === SIG_EOCD) {
      at = i;
      break;
    }
  }
  if (at < 0) return null;

  const total = tail.getUint16(at + 10, true);
  const cdSize = tail.getUint32(at + 12, true);
  const cdOffset = tail.getUint32(at + 16, true);
  if (total === 0xffff || cdSize === 0xffffffff || cdOffset === 0xffffffff) return 'zip64';
  if (cdOffset + cdSize > file.size) return null;

  const buf = await file.slice(cdOffset, cdOffset + cdSize).arrayBuffer();
  const dv = new DataView(buf);
  const bytes = new Uint8Array(buf);
  const decoder = new TextDecoder('utf-8');
  const entries: Entry[] = [];
  let p = 0;
  while (p + 46 <= dv.byteLength && entries.length < MAX_ENTRIES) {
    if (dv.getUint32(p, true) !== SIG_CEN) break;
    const nameLen = dv.getUint16(p + 28, true);
    const extraLen = dv.getUint16(p + 30, true);
    const commentLen = dv.getUint16(p + 32, true);
    if (p + 46 + nameLen > dv.byteLength) break;
    entries.push({
      flags: dv.getUint16(p + 8, true),
      method: dv.getUint16(p + 10, true),
      compSize: dv.getUint32(p + 20, true),
      size: dv.getUint32(p + 24, true),
      offset: dv.getUint32(p + 42, true),
      name: decoder.decode(bytes.subarray(p + 46, p + 46 + nameLen)).replace(/\\/g, '/'),
    });
    p += 46 + nameLen + extraLen + commentLen;
  }
  return entries;
}

export async function inspectZip(file: Blob): Promise<ZipReport> {
  const report = emptyReport();
  try {
    if (file.size < 22) {
      report.errors.push('This file is too small to be a ZIP archive.');
      return report;
    }
    const magic = new Uint8Array(await file.slice(0, 4).arrayBuffer());
    if (magic[0] !== 0x50 || magic[1] !== 0x4b) {
      report.errors.push('This is not a ZIP file. Choose a .zip archive, or switch to a single HTML file.');
      return report;
    }

    const dir = await readDirectory(file);
    if (dir === 'zip64') {
      report.unreadable = true;
      report.ok = true;
      report.notes.push('This archive uses the ZIP64 format, so it cannot be checked here. The cloud build will still try it.');
      return report;
    }
    if (!dir) {
      report.errors.push('The ZIP is damaged or incomplete. Create it again and retry.');
      return report;
    }

    const files = dir.filter((e) => !e.name.endsWith('/') && !isJunk(e.name));
    report.fileCount = files.length;
    report.totalBytes = files.reduce((sum, e) => sum + e.size, 0);

    if (files.length === 0) {
      report.errors.push('The ZIP is empty.');
      return report;
    }

    const indexes = files
      .filter((e) => (e.name === 'index.html' || e.name.endsWith('/index.html')) && !e.name.includes('node_modules/'))
      .sort((a, b) => depth(a.name) - depth(b.name) || a.name.localeCompare(b.name));
    const index = indexes[0];

    if (!index) {
      const near = files.find((e) => /(^|\/)index\.html?$/i.test(e.name));
      report.errors.push(
        near
          ? `Found "${near.name}", but the file must be named exactly index.html (lowercase).`
          : 'No index.html found. Put an index.html at the top of the ZIP (or inside one folder).',
      );
    } else {
      report.ok = true;
      report.indexPath = index.name;
      const folder = index.name.includes('/') ? index.name.slice(0, index.name.lastIndexOf('/') + 1) : '';
      if (folder) report.notes.push(`index.html is inside "${folder}", so that folder becomes the app root.`);

      const html = await readEntryText(file, index);
      if (html) {
        const title = /<title[^>]*>([^<]{1,80})<\/title>/i.exec(html);
        if (title) report.title = title[1].replace(/\s+/g, ' ').trim();
        if (!/<meta[^>]+name=["']viewport["']/i.test(html)) {
          report.warnings.push('index.html has no viewport tag, so the app may look zoomed out on phones.');
        }
      }

      const manifest = files.find(
        (e) => e.name === `${folder}manifest.json` || e.name === `${folder}manifest.webmanifest`,
      );
      if (manifest) {
        const text = await readEntryText(file, manifest);
        if (text) {
          try {
            const json = JSON.parse(text) as { name?: unknown; short_name?: unknown };
            const name =
              typeof json.name === 'string' ? json.name : typeof json.short_name === 'string' ? json.short_name : '';
            if (name.trim()) report.manifestName = name.trim().slice(0, 40);
          } catch {
            /* an unreadable manifest is not our problem */
          }
        }
      }

      const pkg = files.find((e) => e.name === `${folder}package.json`);
      if (pkg) {
        const text = await readEntryText(file, pkg);
        if (text && /"build"\s*:/.test(text)) {
          report.hasBuildScript = true;
          report.notes.push('This project has a build script, so it will be built with npm first. That adds a minute or two.');
        }
      }
    }

    if (files.some((e) => e.name.includes('node_modules/'))) {
      report.warnings.push('The ZIP contains node_modules. Remove it to make the upload much smaller.');
    }
    if (files.some((e) => e.name.split('/').includes('..') || e.name.startsWith('/'))) {
      report.warnings.push('Some files use unsafe paths and will be skipped during the build.');
    }
    if (report.totalBytes > 150 * 1024 * 1024) {
      report.warnings.push('The unpacked project is very large. The app may be slow to install.');
    }
    return report;
  } catch {
    report.errors.push('Could not read this file. Choose another ZIP.');
    return report;
  }
}
