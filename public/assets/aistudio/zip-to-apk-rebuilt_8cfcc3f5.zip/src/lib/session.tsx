/* One place that knows who is signed in and what their plan and credits are. */

import type { User } from '@supabase/supabase-js';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { fetchProfile } from '@/services/account';
import { hideBanner } from '@/services/ads';
import type { Plan, Profile } from '@/types';
import { friendlyError } from './errors';
import { navigate } from './router';
import { supabase } from './supabase';

interface SessionValue {
  /** True until the first session check has finished. */
  loading: boolean;
  user: User | null;
  profile: Profile | null;
  profileError: string | null;
  plan: Plan;
  paid: boolean;
  refreshProfile: () => Promise<void>;
  patchProfile: (patch: Partial<Profile>) => void;
  signOut: () => Promise<void>;
}

const Ctx = createContext<SessionValue | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [profileError, setProfileError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    supabase.auth
      .getSession()
      .then(({ data }) => {
        if (!alive) return;
        setUser(data.session?.user ?? null);
        setLoading(false);
      })
      .catch(() => alive && setLoading(false));

    // Keep this callback synchronous: awaiting Supabase calls inside it can deadlock the client.
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser((prev) => (prev?.id === session?.user?.id ? prev : (session?.user ?? null)));
    });
    return () => {
      alive = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const userId = user?.id ?? null;

  const refreshProfile = useCallback(async () => {
    if (!userId) return;
    try {
      setProfile(await fetchProfile(userId));
      setProfileError(null);
    } catch (err) {
      setProfileError(friendlyError(err));
    }
  }, [userId]);

  useEffect(() => {
    if (!userId) {
      setProfile(null);
      setProfileError(null);
      return;
    }
    void refreshProfile();
  }, [userId, refreshProfile]);

  const patchProfile = useCallback((patch: Partial<Profile>) => {
    setProfile((p) => (p ? { ...p, ...patch } : p));
  }, []);

  const signOut = useCallback(async () => {
    await hideBanner();
    await supabase.auth.signOut();
    setProfile(null);
    navigate('welcome', undefined, true);
  }, []);

  const value = useMemo<SessionValue>(() => {
    const plan: Plan = profile?.plan ?? 'free';
    return {
      loading,
      user,
      profile,
      profileError,
      plan,
      paid: plan === 'pro' || plan === 'developer',
      refreshProfile,
      patchProfile,
      signOut,
    };
  }, [loading, user, profile, profileError, refreshProfile, patchProfile, signOut]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSession(): SessionValue {
  const value = useContext(Ctx);
  if (!value) throw new Error('useSession must be used inside SessionProvider');
  return value;
}
