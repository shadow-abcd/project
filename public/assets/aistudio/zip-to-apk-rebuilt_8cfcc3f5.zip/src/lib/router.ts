/* A tiny hash router. Hash URLs work on any static host and inside the Android WebView,
   and every screen becomes a history entry so the Back button behaves. */

import { useSyncExternalStore } from 'react';

export type RouteName = 'welcome' | 'auth' | 'home' | 'build' | 'projects' | 'settings';

const NAMES: ReadonlySet<string> = new Set(['welcome', 'auth', 'home', 'build', 'projects', 'settings']);

export interface RouteState {
  name: RouteName | null;
  params: URLSearchParams;
}

let cachedRaw = '\u0000';
let cached: RouteState = { name: null, params: new URLSearchParams() };

function snapshot(): RouteState {
  const raw = window.location.hash.replace(/^#\/?/, '');
  if (raw !== cachedRaw) {
    cachedRaw = raw;
    const [path, query = ''] = raw.split('?');
    cached = { name: NAMES.has(path) ? (path as RouteName) : null, params: new URLSearchParams(query) };
  }
  return cached;
}

function subscribe(listener: () => void): () => void {
  window.addEventListener('hashchange', listener);
  return () => window.removeEventListener('hashchange', listener);
}

export function useRoute(): RouteState {
  return useSyncExternalStore(subscribe, snapshot, snapshot);
}

export function routeHref(name: RouteName, params?: Record<string, string>): string {
  const q = params && Object.keys(params).length ? `?${new URLSearchParams(params).toString()}` : '';
  return `#/${name}${q}`;
}

export function navigate(name: RouteName, params?: Record<string, string>, replace = false): void {
  const target = routeHref(name, params);
  if (replace) {
    window.history.replaceState(null, '', target);
    window.dispatchEvent(new HashChangeEvent('hashchange'));
  } else {
    window.location.hash = target;
  }
}
