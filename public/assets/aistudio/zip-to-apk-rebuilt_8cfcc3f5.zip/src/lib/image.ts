/* Turns whatever image the user picks into a square 512 px PNG, which is what the launcher icon needs.
   It also keeps the saved project small enough for localStorage. */

const MAX_BYTES = 5 * 1024 * 1024;
const ALLOWED = /^image\/(png|jpeg|webp|svg\+xml)$/;

export interface PreparedIcon {
  dataUrl: string;
  blob: Blob;
  sourceWidth: number;
  sourceHeight: number;
  lowRes: boolean;
  cropped: boolean;
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('That image could not be read. Try a PNG or JPEG.'));
    img.src = url;
  });
}

export async function prepareIcon(file: File, size = 512): Promise<PreparedIcon> {
  if (!ALLOWED.test(file.type)) throw new Error('Choose a PNG, JPEG, WebP or SVG image.');
  if (file.size > MAX_BYTES) throw new Error('That image is larger than 5 MB.');

  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const w = img.naturalWidth || size;
    const h = img.naturalHeight || size;
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Your browser cannot process images.');
    ctx.imageSmoothingQuality = 'high';
    const scale = Math.max(size / w, size / h); // cover: fill the square, crop the overflow
    const dw = w * scale;
    const dh = h * scale;
    ctx.drawImage(img, (size - dw) / 2, (size - dh) / 2, dw, dh);

    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png'));
    if (!blob) throw new Error('The image could not be converted.');
    return {
      blob,
      dataUrl: canvas.toDataURL('image/png'),
      sourceWidth: w,
      sourceHeight: h,
      lowRes: Math.min(w, h) < 192 && file.type !== 'image/svg+xml',
      cropped: Math.abs(w - h) > 2,
    };
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function dataUrlToBlob(dataUrl: string): Blob {
  const [head, body = ''] = dataUrl.split(',');
  const mime = /data:([^;]+)/.exec(head)?.[1] ?? 'image/png';
  const bin = atob(body);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}
