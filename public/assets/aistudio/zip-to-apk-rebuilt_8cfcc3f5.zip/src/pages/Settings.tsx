import { useRef, useState } from 'react';
import { Icon } from '@/components/Icon';
import { Modal } from '@/components/Modal';
import { APP_NAME, APP_VERSION } from '@/config/brand';
import { SUPABASE_ANON_KEY, SUPABASE_URL, WORKER_CONFIGURED, WORKER_URL } from '@/config/env';
import { isNative } from '@/lib/platform';
import { slugify } from '@/lib/package-id';
import { useCanInstall, promptInstall } from '@/lib/pwa';
import { useSession } from '@/lib/session';
import { clearProjects, exportProjects, importProjects, projectStats } from '@/lib/store';
import { getTheme, setTheme, type ThemeChoice } from '@/lib/theme';
import { toast } from '@/lib/toast';

const THEMES: Array<{ id: ThemeChoice; label: string; icon: 'phone' | 'sun' | 'moon' }> = [
  { id: 'system', label: 'System', icon: 'phone' },
  { id: 'light', label: 'Light', icon: 'sun' },
  { id: 'dark', label: 'Dark', icon: 'moon' },
];


interface CheckLine {
  ok: boolean;
  text: string;
}

async function timedFetch(url: string, init?: RequestInit): Promise<Response> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 8000);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    window.clearTimeout(timer);
  }
}

/** Checks the two services the app depends on, so a setup problem is named instead of guessed. */
async function checkConnections(): Promise<CheckLine[]> {
  const lines: CheckLine[] = [{ ok: true, text: `${APP_NAME} ${APP_VERSION} on ${isNative ? 'Android' : 'the web'}` }];

  try {
    const r = await timedFetch(`${SUPABASE_URL}/auth/v1/health`, { headers: { apikey: SUPABASE_ANON_KEY } });
    lines.push({ ok: r.ok, text: r.ok ? 'Account service is reachable' : `The account service answered with error ${r.status}` });
  } catch {
    lines.push({ ok: false, text: 'The account service is unreachable. Check your internet connection.' });
  }

  if (!WORKER_CONFIGURED) {
    lines.push({ ok: false, text: 'The build service is not set. Add the WORKER_URL variable in GitHub, then build the app again.' });
  } else {
    try {
      const r = await timedFetch(`${WORKER_URL}/health`);
      const body = (await r.json().catch(() => ({}))) as { configured?: boolean };
      if (!r.ok) lines.push({ ok: false, text: `The build service answered with error ${r.status}` });
      else if (body.configured) lines.push({ ok: true, text: 'Build service is reachable and ready' });
      else lines.push({ ok: false, text: 'The build service is reachable but is missing its secrets. See the README, step 3.' });
    } catch {
      lines.push({ ok: false, text: 'The build service is unreachable. Check the WORKER_URL address.' });
    }
  }
  return lines;
}

export default function Settings() {
  const { user, plan, signOut } = useSession();
  const [theme, setThemeState] = useState<ThemeChoice>(getTheme);
  const [stats, setStats] = useState(projectStats);
  const [confirmClear, setConfirmClear] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const canInstall = useCanInstall();
  const [checks, setChecks] = useState<CheckLine[] | null>(null);
  const [checking, setChecking] = useState(false);

  function pickTheme(choice: ThemeChoice) {
    setTheme(choice);
    setThemeState(choice);
  }

  function download() {
    const blob = new Blob([exportProjects()], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${slugify(APP_NAME)}-projects.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }

  async function onImport(file: File | undefined) {
    if (!file) return;
    try {
      const added = importProjects(await file.text());
      setStats(projectStats());
      toast(added > 0 ? `Imported ${added} project${added === 1 ? '' : 's'}.` : 'Nothing new to import.', added > 0 ? 'success' : 'info');
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Could not import that file.', 'error');
    } finally {
      if (fileInput.current) fileInput.current.value = '';
    }
  }

  async function runChecks() {
    setChecking(true);
    try {
      setChecks(await checkConnections());
    } finally {
      setChecking(false);
    }
  }

  function clearAll() {
    clearProjects();
    setStats(projectStats());
    setConfirmClear(false);
    toast('Saved projects deleted from this device.', 'info');
  }

  return (
    <div className="page stack">
      <div className="page-head">
        <h1>Settings</h1>
      </div>

      <section className="card" aria-labelledby="acct">
        <h2 id="acct">Account</h2>
        <dl className="kv" style={{ margin: '12px 0 16px' }}>
          <dt>Email</dt>
          <dd>{user?.email}</dd>
          <dt>Plan</dt>
          <dd style={{ textTransform: 'capitalize' }}>{plan}</dd>
        </dl>
        <button className="btn btn-secondary" onClick={() => void signOut()}>
          <Icon name="logout" /> Sign out
        </button>
      </section>

      <section className="card" aria-labelledby="look">
        <h2 id="look">Appearance</h2>
        <div className="seg" role="group" aria-label="Theme" style={{ marginTop: 12 }}>
          {THEMES.map((t) => (
            <button key={t.id} aria-pressed={theme === t.id} onClick={() => pickTheme(t.id)}>
              {t.label}
            </button>
          ))}
        </div>
        {canInstall && (
          <button className="btn btn-secondary" style={{ marginTop: 14 }} onClick={() => void promptInstall()}>
            <Icon name="download" /> Install this app
          </button>
        )}
      </section>

      <section className="card" aria-labelledby="diag">
        <h2 id="diag">Connection check</h2>
        <p className="muted small" style={{ margin: '4px 0 12px' }}>
          If builds do not start, this shows which part is not answering.
        </p>
        <button className="btn btn-secondary btn-sm" onClick={() => void runChecks()} disabled={checking}>
          <Icon name={checking ? 'loader' : 'refresh'} size={16} className={checking ? 'spin' : undefined} />
          {checking ? 'Checking' : 'Run check'}
        </button>
        {checks && (
          <div className="check-list" style={{ marginTop: 14 }} aria-live="polite">
            {checks.map((c) => (
              <div key={c.text} className={`check-row ${c.ok ? 'pass' : 'fail'}`}>
                <Icon name={c.ok ? 'check' : 'x'} size={18} />
                <span>{c.text}</span>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="card" aria-labelledby="data">
        <h2 id="data">Your data</h2>
        <p className="muted small" style={{ margin: '4px 0 12px' }}>
          Project settings are stored only on this device. Source files are uploaded when you build and are not kept in your saved projects.
        </p>
        <div className="stats" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 14 }}>
          <div className="stat">
            <span className="stat-label">Projects</span>
            <span className="stat-value">{stats.projects}</span>
          </div>
          <div className="stat">
            <span className="stat-label">Builds</span>
            <span className="stat-value">{stats.builds}</span>
          </div>
          <div className="stat">
            <span className="stat-label">Built</span>
            <span className="stat-value">{stats.succeeded}</span>
          </div>
          <div className="stat">
            <span className="stat-label">Failed</span>
            <span className="stat-value">{stats.failed}</span>
          </div>
        </div>
        <div className="row">
          <button className="btn btn-secondary btn-sm" onClick={download} disabled={stats.projects === 0}>
            <Icon name="download" size={16} /> Export
          </button>
          <button className="btn btn-secondary btn-sm" onClick={() => fileInput.current?.click()}>
            <Icon name="upload" size={16} /> Import
          </button>
          <button className="btn btn-danger btn-sm" onClick={() => setConfirmClear(true)} disabled={stats.projects === 0}>
            <Icon name="trash" size={16} /> Delete all
          </button>
          <input
            ref={fileInput}
            type="file"
            accept="application/json,.json"
            className="sr-only"
            tabIndex={-1}
            aria-hidden="true"
            onChange={(e) => void onImport(e.target.files?.[0])}
          />
        </div>
      </section>

      <p className="muted small center">
        {APP_NAME} {APP_VERSION}
      </p>

      <Modal
        open={confirmClear}
        title="Delete all saved projects?"
        onClose={() => setConfirmClear(false)}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setConfirmClear(false)}>
              Cancel
            </button>
            <button className="btn btn-danger" onClick={clearAll}>
              Delete {stats.projects}
            </button>
          </>
        }
      >
        <p>This removes every saved project and its build history from this device. It cannot be undone. Export first if you want a copy.</p>
      </Modal>
    </div>
  );
}
