import { Logo } from '@/components/Logo';
import { ZipperRule } from '@/components/Illustrations';
import { Icon } from '@/components/Icon';
import { APP_NAME } from '@/config/brand';
import { routeHref } from '@/lib/router';

export default function Welcome() {
  return (
    <div className="welcome">
      <header className="welcome-bar">
        <span className="brand">
          <Logo size={30} />
          {APP_NAME}
        </span>
        <a className="btn btn-secondary btn-sm" href={routeHref('auth')}>
          Sign in
        </a>
      </header>

      <div className="hero">
        <h1>Turn a zipped web project into an Android app.</h1>
        <p className="lead">
          Upload a ZIP or a single HTML file. We build the APK in the cloud and hand it back, ready to install. No Android Studio, no
          command line.
        </p>
        <div className="row">
          <a className="btn btn-primary btn-lg" href={routeHref('auth', { mode: 'signup' })}>
            Create a free account
          </a>
          <a className="btn btn-secondary btn-lg" href={routeHref('auth')}>
            Sign in
          </a>
        </div>
        <ZipperRule />
      </div>

      <section aria-labelledby="how">
        <h2 id="how">How it works</h2>
        <ol className="steps">
          <li>
            <div>
              <strong>Bring your project</strong>
              <span>Upload a ZIP with an index.html, a single HTML file, or paste a link to one.</span>
            </div>
          </li>
          <li>
            <div>
              <strong>Name it and pick an icon</strong>
              <span>Set the app name, launcher icon, colors and screen orientation.</span>
            </div>
          </li>
          <li>
            <div>
              <strong>Choose what it can do</strong>
              <span>Camera, location, notifications and deep links, only if your app needs them.</span>
            </div>
          </li>
          <li>
            <div>
              <strong>Install the APK</strong>
              <span>A few minutes later your finished file is ready to download and install.</span>
            </div>
          </li>
        </ol>
      </section>

      <section aria-labelledby="plans">
        <h2 id="plans">Free to try</h2>
        <dl className="defs">
          <div>
            <dt>Free</dt>
            <dd>Your first build is on us. Watch two short ads for each extra build.</dd>
          </div>
          <div>
            <dt>Pro</dt>
            <dd>No ads, no credits, and your own package name for Google Play.</dd>
          </div>
        </dl>
      </section>

      <p className="fine">
        <Icon name="shield" size={14} /> Only convert projects that are yours, or that you have permission to use.
      </p>
    </div>
  );
}
