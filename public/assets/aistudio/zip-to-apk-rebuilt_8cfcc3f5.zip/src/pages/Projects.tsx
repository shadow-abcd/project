import { useEffect, useMemo, useState } from 'react';
import { EmptyProjects } from '@/components/Illustrations';
import { Icon } from '@/components/Icon';
import { Modal } from '@/components/Modal';
import { ProjectBadge } from '@/components/StatusBadge';
import { cx, formatDate } from '@/lib/format';
import { navigate } from '@/lib/router';
import { deleteProject, duplicateProject, listProjects, setProjectStatus, subscribeProjects } from '@/lib/store';
import { toast } from '@/lib/toast';
import type { Project, ProjectStatus } from '@/types';

const FILTERS: Array<{ id: 'all' | ProjectStatus; label: string }> = [
  { id: 'all', label: 'All' },
  { id: 'draft', label: 'Drafts' },
  { id: 'completed', label: 'Built' },
  { id: 'failed', label: 'Failed' },
  { id: 'archived', label: 'Archived' },
];

function sourceLabel(p: Project): string {
  if (p.source.kind === 'link') return 'Link';
  return p.source.fileName ?? 'Upload';
}

export default function Projects() {
  const [projects, setProjects] = useState<Project[]>(() => listProjects());
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<'all' | ProjectStatus>('all');
  const [confirming, setConfirming] = useState<Project | null>(null);

  useEffect(() => subscribeProjects(() => setProjects(listProjects())), []);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    return projects.filter((p) => {
      if (filter === 'all' ? p.status === 'archived' : p.status !== filter) return false;
      if (!q) return true;
      return p.name.toLowerCase().includes(q) || p.settings.packageId.toLowerCase().includes(q);
    });
  }, [projects, query, filter]);

  const archivedCount = projects.filter((p) => p.status === 'archived').length;

  function copy(id: string) {
    if (duplicateProject(id)) toast('Project duplicated.', 'success');
  }

  function remove() {
    if (!confirming) return;
    deleteProject(confirming.id);
    setConfirming(null);
    toast('Project deleted.', 'info');
  }

  return (
    <div className="page stack">
      <div className="row-between">
        <div className="page-head">
          <h1>Projects</h1>
          <p className="muted">
            {projects.length === 0 ? 'Saved on this device.' : `${projects.length} saved on this device`}
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => navigate('build')}>
          <Icon name="plus" /> New
        </button>
      </div>

      {projects.length === 0 ? (
        <div className="card empty">
          <EmptyProjects />
          <h2>No projects yet</h2>
          <p>Every build you start is saved here, so you can reuse its settings next time.</p>
          <button className="btn btn-primary" onClick={() => navigate('build')}>
            Create your first app
          </button>
        </div>
      ) : (
        <>
          <div className="field">
            <label className="sr-only" htmlFor="project-search">
              Search projects
            </label>
            <input
              id="project-search"
              className="input"
              type="search"
              placeholder="Search by name or package"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>

          <div className="seg" role="group" aria-label="Filter projects">
            {FILTERS.map((f) => (
              <button key={f.id} aria-pressed={filter === f.id} onClick={() => setFilter(f.id)}>
                {f.label}
              </button>
            ))}
          </div>

          {visible.length === 0 ? (
            <p className="muted center">
              {filter === 'all' && archivedCount === projects.length ? 'Everything is archived. Open the Archived tab.' : 'No projects match.'}
            </p>
          ) : (
            <div className="stack-sm">
              {visible.map((p) => (
                <article className="card" key={p.id} aria-label={p.name}>
                  <div className="row" style={{ flexWrap: 'nowrap' }}>
                    <div
                      className={cx('icon-tile')}
                      style={{
                        width: 52,
                        height: 52,
                        fontSize: '1.25rem',
                        backgroundColor: p.settings.primaryColor,
                        backgroundImage: p.settings.logoDataUrl ? `url(${p.settings.logoDataUrl})` : undefined,
                      }}
                      aria-hidden="true"
                    >
                      {!p.settings.logoDataUrl && (p.name.charAt(0).toUpperCase() || '?')}
                    </div>
                    <div className="grow">
                      <div className="row" style={{ gap: 8 }}>
                        <h3 className="truncate">{p.name}</h3>
                        <ProjectBadge status={p.status} />
                      </div>
                      <p className="muted small truncate mono">{p.settings.packageId || 'Package assigned on build'}</p>
                      <p className="muted small truncate">
                        {sourceLabel(p)} · {formatDate(p.updatedAt)}
                        {p.builds.length > 0 && ` · ${p.builds.length} build${p.builds.length === 1 ? '' : 's'}`}
                      </p>
                    </div>
                  </div>
                  <div className="row" style={{ marginTop: 12 }}>
                    <button className="btn btn-secondary btn-sm" onClick={() => navigate('build', { project: p.id })}>
                      <Icon name="refresh" size={16} /> Build again
                    </button>
                    <button className="btn btn-ghost btn-sm" onClick={() => copy(p.id)} aria-label={`Duplicate ${p.name}`}>
                      <Icon name="copy" size={16} />
                    </button>
                    <button
                      className="btn btn-ghost btn-sm"
                      onClick={() => setProjectStatus(p.id, p.status === 'archived' ? 'draft' : 'archived')}
                      aria-label={p.status === 'archived' ? `Restore ${p.name}` : `Archive ${p.name}`}
                    >
                      <Icon name="archive" size={16} />
                    </button>
                    <button className="btn btn-ghost btn-sm" onClick={() => setConfirming(p)} aria-label={`Delete ${p.name}`}>
                      <Icon name="trash" size={16} />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          )}
        </>
      )}

      <Modal
        open={!!confirming}
        title="Delete this project?"
        onClose={() => setConfirming(null)}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setConfirming(null)}>
              Keep it
            </button>
            <button className="btn btn-danger" onClick={remove}>
              Delete
            </button>
          </>
        }
      >
        <p>
          <strong>{confirming?.name}</strong> and its saved settings will be removed from this device. APKs you already built stay on
          Home.
        </p>
      </Modal>
    </div>
  );
}
