import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { EmptyBuilds } from '@/components/Illustrations';
import { Icon } from '@/components/Icon';
import { JobBadge } from '@/components/StatusBadge';
import { ADS_PER_CREDIT } from '@/config/env';
import { friendlyError } from '@/lib/errors';
import { formatDateTime } from '@/lib/format';
import { openExternal } from '@/lib/platform';
import { navigate } from '@/lib/router';
import { useSession } from '@/lib/session';
import { toast } from '@/lib/toast';
import { recordAdView, redeemCoupon } from '@/services/account';
import { rewardedAdsAvailable, showRewardedAd } from '@/services/ads';
import { apkDownloadUrl, isPending, listBuilds } from '@/services/builds';
import type { BuildRow } from '@/types';

const POLL_MS = 6000;
const POLL_LIMIT_MS = 20 * 60 * 1000;

/** Loads recent builds and keeps them fresh while one is queued or building. */
function useBuilds(onFailedOrDone: () => void) {
  const [rows, setRows] = useState<BuildRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const previous = useRef(new Map<string, string>());
  const pollStart = useRef(0);
  const timer = useRef<number | undefined>(undefined);
  const notify = useRef(onFailedOrDone);
  notify.current = onFailedOrDone;

  const load = useCallback(async () => {
    window.clearTimeout(timer.current);
    try {
      const data = await listBuilds();
      setRows(data);
      setError(null);

      let changed = false;
      for (const job of data) {
        const before = previous.current.get(job.id);
        if (before && before !== job.status) {
          changed = true;
          if (job.status === 'done') toast(`${job.app_name} is ready to download.`, 'success');
          if (job.status === 'failed') toast(`${job.app_name} could not be built.`, 'error');
        }
        previous.current.set(job.id, job.status);
      }
      if (changed) notify.current(); // credits may have changed (a failed build is refunded)

      if (data.some((j) => isPending(j.status))) {
        if (!pollStart.current) pollStart.current = Date.now();
        if (Date.now() - pollStart.current < POLL_LIMIT_MS) timer.current = window.setTimeout(load, POLL_MS);
      } else {
        pollStart.current = 0;
      }
    } catch (err) {
      setError(friendlyError(err));
    }
  }, []);

  useEffect(() => {
    void load();
    const onVisible = () => {
      if (!document.hidden) void load();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      document.removeEventListener('visibilitychange', onVisible);
      window.clearTimeout(timer.current);
    };
  }, [load]);

  return { rows, error, reload: load };
}

function EarnCard() {
  const { profile, patchProfile } = useSession();
  const [busy, setBusy] = useState(false);
  if (!profile) return null;

  const left = ADS_PER_CREDIT - profile.adProgress;

  async function watch() {
    if (busy) return;
    setBusy(true);
    try {
      const rewarded = await showRewardedAd();
      if (!rewarded) {
        toast('The ad was closed early, so no progress was counted.', 'info');
        return;
      }
      const result = await recordAdView();
      patchProfile({ credits: result.credits, adViews: result.adViews, adProgress: result.adProgress });
      toast(
        result.earnedCredit ? '+1 build credit added.' : `Ad 1 of ${ADS_PER_CREDIT} watched. Watch one more for a credit.`,
        'success',
      );
    } catch (err) {
      toast(friendlyError(err), 'error');
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="card" aria-labelledby="earn-title">
      <div className="card-head">
        <div>
          <h2 id="earn-title">Earn a build credit</h2>
          <p className="muted small">A build costs one credit. {ADS_PER_CREDIT === 2 ? 'Two short ads earn you one.' : ''}</p>
        </div>
        <span className="badge badge-neutral">
          {profile.adProgress} of {ADS_PER_CREDIT}
        </span>
      </div>
      {rewardedAdsAvailable ? (
        <button className="btn btn-secondary btn-block" onClick={watch} disabled={busy}>
          <Icon name={busy ? 'loader' : 'play'} className={busy ? 'spin' : undefined} />
          {busy ? 'Loading ad' : `Watch an ad (${left} to go)`}
        </button>
      ) : (
        <p className="muted small">Rewarded ads are not available here. Use a coupon below, or open the Android app.</p>
      )}
    </section>
  );
}

function BuildsCard({ rows, error, reload }: { rows: BuildRow[] | null; error: string | null; reload: () => void }) {
  const [opening, setOpening] = useState<string | null>(null);

  async function download(job: BuildRow) {
    if (!job.apk_path || opening) return;
    setOpening(job.id);
    try {
      openExternal(await apkDownloadUrl(job.apk_path));
    } catch (err) {
      toast(friendlyError(err), 'error');
    } finally {
      setOpening(null);
    }
  }

  return (
    <section className="card" aria-labelledby="builds-title">
      <div className="card-head">
        <h2 id="builds-title">Recent builds</h2>
        <button className="btn btn-ghost btn-sm" onClick={reload} aria-label="Refresh builds">
          <Icon name="refresh" size={16} />
        </button>
      </div>

      {error && (
        <div className="alert alert-bad" role="alert">
          <Icon name="alert" />
          <span>{error}</span>
        </div>
      )}

      {rows === null && !error && <p className="muted">Loading builds</p>}

      {rows && rows.length === 0 && (
        <div className="empty">
          <EmptyBuilds />
          <p>Nothing built yet. Your finished APKs will wait here for you.</p>
          <button className="btn btn-primary" onClick={() => navigate('build')}>
            <Icon name="plus" /> Start a build
          </button>
        </div>
      )}

      {rows && rows.length > 0 && (
        <div className="list">
          {rows.map((job) => (
            <div className="list-item" key={job.id}>
              <div className="grow">
                <div className="row" style={{ gap: 8 }}>
                  <strong className="truncate">{job.app_name}</strong>
                  <span className="muted small">v{job.version_name}</span>
                  <JobBadge status={job.status} />
                </div>
                <p className="muted small">{formatDateTime(job.created_at)}</p>
                {job.status === 'failed' && job.error && <p className="error-text break">{job.error}</p>}
              </div>
              {job.status === 'done' && job.apk_path && (
                <button className="btn btn-ok btn-sm" onClick={() => download(job)} disabled={opening === job.id}>
                  <Icon name={opening === job.id ? 'loader' : 'download'} size={16} className={opening === job.id ? 'spin' : undefined} />
                  APK
                </button>
              )}
              {isPending(job.status) && <Icon name="loader" className="spin" />}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

function CouponCard() {
  const { refreshProfile } = useSession();
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);

  async function submit(e: FormEvent) {
    e.preventDefault();
    const value = code.trim();
    if (!value) return setMessage({ ok: false, text: 'Enter a coupon code.' });
    setBusy(true);
    setMessage(null);
    try {
      const result = await redeemCoupon(value);
      setMessage({ ok: result.ok, text: result.message });
      if (result.ok) {
        setCode('');
        toast(result.message, 'success');
        await refreshProfile();
      }
    } catch (err) {
      setMessage({ ok: false, text: friendlyError(err) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="card" aria-labelledby="coupon-title">
      <h2 id="coupon-title">Have a code?</h2>
      <form className="stack-sm" style={{ marginTop: 12 }} onSubmit={submit}>
        <div className="field">
          <label className="label" htmlFor="coupon">
            Coupon code
          </label>
          <input
            id="coupon"
            className="input"
            style={{ textTransform: 'uppercase' }}
            autoComplete="off"
            autoCapitalize="characters"
            spellCheck={false}
            value={code}
            onChange={(e) => setCode(e.target.value)}
          />
        </div>
        <button className="btn btn-secondary" type="submit" disabled={busy}>
          {busy ? 'Checking' : 'Redeem'}
        </button>
        {message && (
          <p className={message.ok ? 'hint' : 'error-text'} role="status">
            {message.text}
          </p>
        )}
      </form>
    </section>
  );
}

export default function Home() {
  const { user, profile, profileError, plan, paid, refreshProfile } = useSession();
  const { rows, error, reload } = useBuilds(refreshProfile);

  return (
    <div className="page stack">
      <div className="page-head">
        <h1>Home</h1>
        <p className="muted break">{user?.email}</p>
      </div>

      {profileError && (
        <div className="alert alert-bad" role="alert">
          <Icon name="alert" />
          <div className="alert-body">
            <span>{profileError}</span>
            <button className="btn btn-secondary btn-sm" onClick={() => void refreshProfile()}>
              Try again
            </button>
          </div>
        </div>
      )}

      <div className="stats">
        <div className="stat">
          <span className="stat-label">Plan</span>
          <span className="stat-value" style={{ textTransform: 'capitalize' }}>
            {profile ? plan : '-'}
          </span>
        </div>
        <div className="stat">
          <span className="stat-label">Credits</span>
          <span className="stat-value">{profile ? (paid ? 'Unlimited' : profile.credits) : '-'}</span>
        </div>
        <div className="stat">
          <span className="stat-label">Ads watched</span>
          <span className="stat-value">{profile ? profile.adViews : '-'}</span>
        </div>
      </div>

      <button className="btn btn-primary btn-lg btn-block" onClick={() => navigate('build')}>
        <Icon name="plus" /> New build
      </button>

      {profile && !paid && <EarnCard />}
      <BuildsCard rows={rows} error={error} reload={() => void reload()} />
      <CouponCard />

      {plan === 'developer' && (
        <section className="card" aria-labelledby="dev-title">
          <h2 id="dev-title">Developer panel</h2>
          <p className="muted small" style={{ margin: '4px 0 12px' }}>
            Your latest builds exactly as stored. Access tokens are never included.
          </p>
          <pre className="code">{JSON.stringify(rows ?? [], null, 2)}</pre>
        </section>
      )}
    </div>
  );
}
