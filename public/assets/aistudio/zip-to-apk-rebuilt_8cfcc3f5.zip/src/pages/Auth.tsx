import { useState, type FormEvent } from 'react';
import { Icon } from '@/components/Icon';
import { Logo } from '@/components/Logo';
import { APP_NAME } from '@/config/brand';
import { friendlyError } from '@/lib/errors';
import { isNative } from '@/lib/platform';
import { navigate, routeHref } from '@/lib/router';
import { supabase } from '@/lib/supabase';

type Mode = 'signin' | 'signup';
type Notice = { kind: 'error' | 'ok'; text: string } | null;

export default function Auth({ initialMode }: { initialMode: Mode }) {
  const [mode, setMode] = useState<Mode>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<Notice>(null);

  const up = mode === 'signup';

  function switchMode(next: Mode) {
    setMode(next);
    setNotice(null);
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setNotice(null);

    const address = email.trim();
    if (!/^\S+@\S+\.\S+$/.test(address)) return setNotice({ kind: 'error', text: 'Enter a valid email address.' });
    if (password.length < 6) return setNotice({ kind: 'error', text: 'Use a password with at least 6 characters.' });
    if (up && password !== confirm) return setNotice({ kind: 'error', text: 'The passwords do not match.' });

    setBusy(true);
    try {
      if (up) {
        const { data, error } = await supabase.auth.signUp({ email: address, password });
        if (error) throw error;
        if (data.session) {
          navigate('home');
          return;
        }
        // Email confirmation is on: the person has to confirm before signing in.
        switchMode('signin');
        setPassword('');
        setConfirm('');
        setNotice({ kind: 'ok', text: 'Account created. Check your email to confirm it, then sign in.' });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email: address, password });
        if (error) throw error;
        navigate('home');
      }
    } catch (err) {
      setNotice({ kind: 'error', text: friendlyError(err) });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth stack">
      <div className="row-between">
        <span className="brand">
          <Logo size={30} />
          {APP_NAME}
        </span>
        {!isNative && (
          <a className="btn btn-ghost btn-sm" href={routeHref('welcome')}>
            Back
          </a>
        )}
      </div>

      <div className="page-head">
        <h1>{up ? 'Create your account' : 'Welcome back'}</h1>
        <p className="muted">{up ? 'Your first build is free.' : 'Sign in to build and download your apps.'}</p>
      </div>

      <div className="seg" role="group" aria-label="Sign in or create account">
        <button type="button" aria-pressed={!up} onClick={() => switchMode('signin')}>
          Sign in
        </button>
        <button type="button" aria-pressed={up} onClick={() => switchMode('signup')}>
          Create account
        </button>
      </div>

      <form onSubmit={onSubmit} noValidate>
        <div className="field">
          <label className="label" htmlFor="email">
            Email
          </label>
          <input
            id="email"
            className="input"
            type="email"
            inputMode="email"
            autoComplete="email"
            autoCapitalize="none"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="field">
          <label className="label" htmlFor="password">
            Password
          </label>
          <div className="input-group">
            <input
              id="password"
              className="input"
              type={show ? 'text' : 'password'}
              autoComplete={up ? 'new-password' : 'current-password'}
              placeholder="6 characters or more"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              type="button"
              className="btn btn-ghost btn-icon"
              onClick={() => setShow((s) => !s)}
              aria-label={show ? 'Hide password' : 'Show password'}
            >
              <Icon name={show ? 'eyeOff' : 'eye'} />
            </button>
          </div>
        </div>

        {up && (
          <div className="field">
            <label className="label" htmlFor="confirm">
              Repeat password
            </label>
            <input
              id="confirm"
              className="input"
              type={show ? 'text' : 'password'}
              autoComplete="new-password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
            />
          </div>
        )}

        {notice && (
          <div className={`alert ${notice.kind === 'error' ? 'alert-bad' : 'alert-ok'}`} role="alert">
            <Icon name={notice.kind === 'error' ? 'alert' : 'check'} />
            <span>{notice.text}</span>
          </div>
        )}

        <button className="btn btn-primary btn-lg btn-block" type="submit" disabled={busy}>
          {busy && <Icon name="loader" className="spin" />}
          {busy ? 'Please wait' : up ? 'Create account' : 'Sign in'}
        </button>
      </form>

      <p className="hint center">Only convert projects that are yours, or that you have permission to use.</p>
    </div>
  );
}
