import { supabase } from '@/lib/supabase';
import type { BuildRow, JobStatus } from '@/types';

const COLUMNS = 'id, status, app_name, package_id, version_name, error, apk_path, created_at, finished_at';

export const isPending = (status: JobStatus): boolean => status === 'queued' || status === 'building';

export async function listBuilds(limit = 15): Promise<BuildRow[]> {
  const { data, error } = await supabase.from('build_jobs').select(COLUMNS).order('created_at', { ascending: false }).limit(limit);
  if (error) throw error;
  return (data ?? []) as BuildRow[];
}

/** A one-hour download link for a finished APK. */
export async function apkDownloadUrl(path: string): Promise<string> {
  const { data, error } = await supabase.storage.from('apks').createSignedUrl(path, 3600);
  if (error || !data) throw new Error('Could not create the download link. Try again.');
  return data.signedUrl;
}
