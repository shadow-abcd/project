/* Ads. Real AdMob on Android; a clearly labelled demo ad on the web so credits can still be earned.
   The server, not this file, decides whether an ad view counts (record_ad_view). */

import {
  AdMob,
  BannerAdPluginEvents,
  BannerAdPosition,
  BannerAdSize,
  InterstitialAdPluginEvents,
  RewardAdPluginEvents,
} from '@capacitor-community/admob';
import { ADMOB_APP_ID, ADMOB_TESTING, AD_UNITS, TEST_DEVICE_IDS } from '@/config/admob';
import { WEB_DEMO_ADS } from '@/config/env';
import { isNative } from '@/lib/platform';

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/* ---------- demo ads (web only) ---------- */

export interface DemoAdRequest {
  title: string;
  seconds: number;
  resolve: (watchedToEnd: boolean) => void;
}

let demoHandler: ((req: DemoAdRequest | null) => void) | null = null;

export function registerDemoAdHost(handler: ((req: DemoAdRequest | null) => void) | null): void {
  demoHandler = handler;
}

function runDemoAd(title: string, seconds: number): Promise<boolean> {
  return new Promise((resolve) => {
    if (!demoHandler) return resolve(false);
    demoHandler({ title, seconds, resolve });
  });
}

/** Can this device show a rewarded ad at all? */
export const rewardedAdsAvailable: boolean = isNative || WEB_DEMO_ADS;

/* ---------- banner ---------- */

export function setBannerHeight(px: number): void {
  document.documentElement.style.setProperty('--banner-h', `${Math.max(0, Math.round(px))}px`);
}

// EU/UK consent (Google UMP). Never blocks the app: on any failure ads follow the last known choice.
async function requestConsent(): Promise<void> {
  try {
    const info = await AdMob.requestConsentInfo({ testDeviceIdentifiers: TEST_DEVICE_IDS });
    if (info && info.status === 'REQUIRED' && info.isConsentFormAvailable) await AdMob.showConsentForm();
  } catch (err) {
    console.warn('Consent check skipped', err);
  }
}

let initialised = false;
let bannerShown = false;

export async function showBanner(): Promise<void> {
  if (!isNative || bannerShown) return;
  try {
    if (!initialised) {
      await AdMob.initialize({ initializeForTesting: ADMOB_TESTING, testingDevices: TEST_DEVICE_IDS });
      await requestConsent();
      await AdMob.addListener(BannerAdPluginEvents.SizeChanged, (size) => setBannerHeight(size.height));
      await AdMob.addListener(BannerAdPluginEvents.FailedToLoad, () => setBannerHeight(0));
      initialised = true;
    }
    await AdMob.showBanner({
      adId: AD_UNITS.banner,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: ADMOB_TESTING,
    });
    bannerShown = true;
  } catch (err) {
    console.warn('Banner ad unavailable', err);
    setBannerHeight(0);
  }
}

export async function hideBanner(): Promise<void> {
  setBannerHeight(0);
  if (!isNative || !bannerShown) return;
  bannerShown = false;
  try {
    await AdMob.removeBanner();
  } catch {
    /* nothing was showing */
  }
}

/* ---------- rewarded ---------- */

/** Resolves true only when the viewer earned the reward. Throws Error('ad_unavailable') when no ad could load. */
export async function showRewardedAd(): Promise<boolean> {
  if (!isNative) {
    if (!WEB_DEMO_ADS) throw new Error('ad_unavailable');
    return runDemoAd('Demo ad. Watch to the end to earn progress.', 5);
  }

  if (!initialised) {
    await AdMob.initialize({ initializeForTesting: ADMOB_TESTING, testingDevices: TEST_DEVICE_IDS });
    await requestConsent();
    initialised = true;
  }

  let rewarded = false;
  let finish: () => void = () => {};
  const closed = new Promise<void>((resolve) => (finish = resolve));
  const handles: Array<{ remove?: () => unknown }> = [];

  try {
    handles.push(await AdMob.addListener(RewardAdPluginEvents.Rewarded, () => (rewarded = true)));
    handles.push(await AdMob.addListener(RewardAdPluginEvents.Dismissed, () => finish()));
    handles.push(await AdMob.addListener(RewardAdPluginEvents.FailedToShow, () => finish()));

    try {
      await AdMob.prepareRewardVideoAd({ adId: AD_UNITS.rewarded, isTesting: ADMOB_TESTING });
    } catch (err) {
      console.warn('Rewarded ad failed to load', err);
      throw new Error('ad_unavailable');
    }

    // Some plugin versions never settle showRewardVideoAd when the ad is skipped,
    // so also wait for the dismissed event, and give up after two minutes.
    AdMob.showRewardVideoAd()
      .then((item) => {
        if (item) rewarded = true;
      })
      .catch((err) => {
        console.warn('Rewarded ad failed to show', err);
        finish();
      });
    await Promise.race([closed, sleep(120_000)]);
  } finally {
    handles.forEach((h) => h.remove?.());
  }
  return rewarded;
}

/* ---------- interstitial (Android, free plan, before a build) ---------- */

/** Never blocks a build: any failure simply skips the ad. */
export async function showInterstitialAd(): Promise<void> {
  if (!isNative) return;
  const handles: Array<{ remove?: () => unknown }> = [];
  try {
    let finish: () => void = () => {};
    const closed = new Promise<void>((resolve) => (finish = resolve));
    handles.push(await AdMob.addListener(InterstitialAdPluginEvents.Dismissed, () => finish()));
    handles.push(await AdMob.addListener(InterstitialAdPluginEvents.FailedToShow, () => finish()));
    await AdMob.prepareInterstitial({ adId: AD_UNITS.interstitial, isTesting: ADMOB_TESTING });
    await AdMob.showInterstitial();
    await Promise.race([closed, sleep(60_000)]);
  } catch (err) {
    console.warn('Interstitial skipped', err);
  } finally {
    handles.forEach((h) => h.remove?.());
  }
}

export { ADMOB_APP_ID };
