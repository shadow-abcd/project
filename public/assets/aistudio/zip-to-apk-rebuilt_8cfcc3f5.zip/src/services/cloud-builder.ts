/* Starts a cloud build and follows it to the end.

   Flow:  upload source (and icon) to Supabase Storage  ->  ask the Worker to start the build
          ->  poll build_jobs until it is done or failed  ->  hand back a signed download link.

   Every step that can fail has a plain-language message, and a build can be abandoned without
   leaving the UI stuck (the server-side job keeps going and shows up on the Home screen). */

import { BUILD_POLL_MS, BUILD_TIMEOUT_MS, WORKER_CONFIGURED, WORKER_URL } from '@/config/env';
import { uid } from '@/lib/format';
import { dataUrlToBlob } from '@/lib/image';
import { errorText, friendlyError } from '@/lib/errors';
import { normalizePackageId, slugify } from '@/lib/package-id';
import { supabase } from '@/lib/supabase';
import type { AppSettings } from '@/types';

export type StageId = 'upload' | 'queue' | 'build' | 'ready';

export const STAGES: ReadonlyArray<{ id: StageId; label: string }> = [
  { id: 'upload', label: 'Upload' },
  { id: 'queue', label: 'Queue' },
  { id: 'build', label: 'Build' },
  { id: 'ready', label: 'Ready' },
];

export type BuildStatus = 'running' | 'done' | 'failed' | 'cancelled';

export interface BuildLogLine {
  at: number;
  level: 'info' | 'warn' | 'error';
  text: string;
}

export interface BuildState {
  status: BuildStatus;
  stage: StageId;
  /** 0 to 100. While the cloud build runs this is an estimate, not a measurement. */
  progress: number;
  logs: BuildLogLine[];
  startedAt: number;
  finishedAt?: number;
  jobId?: string;
  packageId?: string;
  credits?: number;
  downloadUrl?: string;
  apkPath?: string;
  error?: string;
  errorCode?: string;
}

export interface BuildRequest {
  source: { kind: 'upload'; file: File } | { kind: 'link'; url: string };
  settings: AppSettings;
  /** Pro and Developer accounts may choose their own package name. */
  paid: boolean;
}

export interface BuildHandle {
  cancel: () => void;
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function progressFor(stage: StageId, buildStartedAt: number | null): number {
  switch (stage) {
    case 'upload':
      return 12;
    case 'queue':
      return 28;
    case 'build': {
      // Eases from 30% towards 92% over a typical few-minute build, and never reaches 100 by itself.
      const seconds = buildStartedAt ? (Date.now() - buildStartedAt) / 1000 : 0;
      return Math.round(30 + 62 * (1 - Math.exp(-seconds / 150)));
    }
    case 'ready':
      return 100;
  }
}

function buildConfig(s: AppSettings, iconUrl?: string) {
  const deepLinks = s.deepLinks
    .map((d) => ({
      scheme: d.scheme.trim().toLowerCase(),
      host: d.host.trim().toLowerCase(),
      pathPrefix: d.pathPrefix.trim() && !d.pathPrefix.trim().startsWith('/') ? `/${d.pathPrefix.trim()}` : d.pathPrefix.trim(),
    }))
    .filter((d) => d.scheme && (['http', 'https'].includes(d.scheme) ? d.host : true));

  return {
    orientation: s.orientation,
    statusBar: s.statusBar,
    primaryColor: s.primaryColor,
    minSdk: s.minSdk,
    permissions: s.permissions,
    deepLinks,
    mixedContent: s.mixedContent,
    webDebugging: s.webDebugging,
    ...(iconUrl ? { iconUrl } : {}),
  };
}

const NOT_RETRYABLE = /row-level|exceeded|too large|Bucket not found|Invalid|not allowed/i;

export function startBuild(req: BuildRequest, onUpdate: (state: BuildState) => void): BuildHandle {
  let cancelled = false;
  let finished = false;
  let buildStartedAt: number | null = null;
  let ticker: number | undefined;

  const state: BuildState = { status: 'running', stage: 'upload', progress: 0, logs: [], startedAt: Date.now() };

  const emit = () => onUpdate({ ...state, logs: [...state.logs] });
  const log = (level: BuildLogLine['level'], text: string) => state.logs.push({ at: Date.now(), level, text });
  const setStage = (stage: StageId) => {
    state.stage = stage;
    state.progress = progressFor(stage, buildStartedAt);
    emit();
  };
  const stop = () => {
    finished = true;
    if (ticker) window.clearInterval(ticker);
    state.finishedAt = Date.now();
  };
  const fail = (message: string, code?: string) => {
    if (finished) return;
    stop();
    state.status = 'failed';
    state.error = message;
    state.errorCode = code;
    log('error', message);
    emit();
  };

  async function uploadSource(path: string, body: Blob, contentType: string) {
    let last: unknown;
    for (let attempt = 0; attempt < 3; attempt++) {
      if (cancelled) return;
      const { error } = await supabase.storage.from('uploads').upload(path, body, { contentType, upsert: false });
      if (!error) return;
      last = error;
      if (NOT_RETRYABLE.test(errorText(error))) break;
      log('warn', `Upload attempt ${attempt + 1} failed. Retrying.`);
      emit();
      await sleep(1500 * (attempt + 1));
    }
    throw last;
  }

  async function signedUploadUrl(path: string): Promise<string> {
    const { data, error } = await supabase.storage.from('uploads').createSignedUrl(path, 3600);
    if (error || !data) throw new Error('Could not prepare the upload link. Try again.');
    return data.signedUrl;
  }

  async function run() {
    if (!WORKER_CONFIGURED) {
      return fail('Builds are not available yet: this app is not connected to a build service.', 'not_configured');
    }
    if (typeof navigator !== 'undefined' && navigator.onLine === false) {
      return fail('You are offline. Connect to the internet and try again.', 'offline');
    }

    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData.session;
    if (!session) return fail('Your session has expired. Sign in again.', 'auth');
    const uidValue = session.user.id;
    const runId = uid();

    /* 1. Source */
    let zipUrl: string;
    if (req.source.kind === 'upload') {
      const file = req.source.file;
      log('info', `Uploading ${file.name}`);
      emit();
      const safe = file.name.replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 80) || 'project.zip';
      const path = `${uidValue}/${runId}/${safe}`;
      const isHtml = /\.html?$/i.test(file.name);
      await uploadSource(path, file, isHtml ? 'text/html' : 'application/zip');
      if (cancelled) return;
      zipUrl = await signedUploadUrl(path);
      log('info', 'Source uploaded');
    } else {
      zipUrl = req.source.url;
      log('info', 'Using the link you provided');
    }

    /* 2. Icon (optional) */
    let iconUrl: string | undefined;
    if (req.settings.logoDataUrl) {
      try {
        const iconPath = `${uidValue}/${runId}/icon.png`;
        await uploadSource(iconPath, dataUrlToBlob(req.settings.logoDataUrl), 'image/png');
        iconUrl = await signedUploadUrl(iconPath);
        log('info', 'Icon uploaded');
      } catch (err) {
        log('warn', `The icon could not be uploaded, so the default icon will be used. (${friendlyError(err)})`);
      }
    }
    if (cancelled) return;

    /* 3. Ask the Worker to start the build */
    setStage('queue');
    log('info', 'Requesting a build');
    emit();

    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 30_000);
    let res: Response;
    try {
      res = await fetch(`${WORKER_URL}/build`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({
          zipUrl,
          appName: req.settings.appName,
          versionName: req.settings.versionName,
          versionCode: Math.floor(Date.now() / 1000), // always rises, so updates install over older builds
          ...(req.paid ? { packageId: normalizePackageId(req.settings.packageId) } : {}),
          config: buildConfig(req.settings, iconUrl),
        }),
        signal: controller.signal,
      });
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        return fail('The build server did not respond in time. Check Recent builds on Home before you try again.', 'timeout');
      }
      throw err;
    } finally {
      window.clearTimeout(timeout);
    }

    const body = (await res.json().catch(() => ({}))) as {
      error?: string;
      code?: string;
      jobId?: string;
      credits?: number;
      packageId?: string;
    };
    if (!res.ok) return fail(body.error || `The build request failed (${res.status}).`, body.code);
    if (!body.jobId) return fail('The build server sent an unexpected reply. Try again.', 'bad_reply');

    state.jobId = body.jobId;
    state.packageId = body.packageId;
    state.credits = typeof body.credits === 'number' ? body.credits : undefined;
    log('info', 'Build queued');
    buildStartedAt = Date.now();
    setStage('build');
    ticker = window.setInterval(() => {
      if (state.stage === 'build' && !finished) {
        state.progress = progressFor('build', buildStartedAt);
        emit();
      }
    }, 1000);

    /* 4. Follow the build */
    const deadline = Date.now() + BUILD_TIMEOUT_MS;
    let misses = 0;
    let announcedBuilding = false;
    while (!cancelled && Date.now() < deadline) {
      await sleep(BUILD_POLL_MS);
      if (cancelled) return;
      const { data, error } = await supabase.from('build_jobs').select('status, error, apk_path').eq('id', body.jobId).maybeSingle();
      if (error || !data) {
        if (++misses === 6) {
          log('warn', 'Having trouble reaching the server. Still trying.');
          emit();
        }
        continue;
      }
      misses = 0;

      if (data.status === 'building' && !announcedBuilding) {
        announcedBuilding = true;
        log('info', 'The build server picked it up');
        emit();
      }
      if (data.status === 'failed') {
        return fail(data.error || 'The build failed. If a credit was used it has been returned.', 'build_failed');
      }
      if (data.status === 'done' && data.apk_path) {
        const link = await supabase.storage.from('apks').createSignedUrl(data.apk_path, 3600);
        stop();
        state.status = 'done';
        state.apkPath = data.apk_path;
        state.downloadUrl = link.data?.signedUrl;
        state.progress = 100;
        state.stage = 'ready';
        log('info', 'Your APK is ready');
        emit();
        return;
      }
    }
    if (!cancelled) {
      fail('The build is taking longer than expected. It may still finish: check Recent builds on Home.', 'timeout');
    }
  }

  emit(); // show the running state immediately
  run().catch((err) => fail(friendlyError(err)));

  return {
    cancel: () => {
      if (cancelled || finished) return;
      cancelled = true;
      stop();
      state.status = 'cancelled';
      log('warn', 'Stopped watching. A build that already started keeps running: find it under Recent builds on Home.');
      emit();
    },
  };
}

export function apkFileName(appName: string, version: string): string {
  const v = version.replace(/[^A-Za-z0-9._-]/g, '') || '1';
  return `${slugify(appName, 'app')}-${v}.apk`;
}
