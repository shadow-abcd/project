import { supabase } from '@/lib/supabase';
import type { Plan, Profile } from '@/types';

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function toPlan(value: unknown): Plan {
  return value === 'pro' || value === 'developer' ? value : 'free';
}

/** Reads the signed-in user's profile. A brand-new account can lag a moment behind its sign-up trigger, so retry. */
export async function fetchProfile(userId: string): Promise<Profile> {
  for (let attempt = 0; attempt < 4; attempt++) {
    const { data, error } = await supabase
      .from('profiles')
      .select('plan, credits, ad_views, ad_progress')
      .eq('id', userId)
      .maybeSingle();
    if (error) throw error;
    if (data) {
      return {
        plan: toPlan(data.plan),
        credits: Number(data.credits) || 0,
        adViews: Number(data.ad_views) || 0,
        adProgress: Number(data.ad_progress) || 0,
      };
    }
    await sleep(700);
  }
  throw new Error('no_profile');
}

export interface AdResult {
  credits: number;
  adViews: number;
  adProgress: number;
  earnedCredit: boolean;
}

/** The server counts the ad (with rate limits) and adds the credit. */
export async function recordAdView(): Promise<AdResult> {
  const { data, error } = await supabase.rpc('record_ad_view');
  if (error) throw error;
  return {
    credits: Number(data?.credits) || 0,
    adViews: Number(data?.ad_views) || 0,
    adProgress: Number(data?.ad_progress) || 0,
    earnedCredit: !!data?.earned_credit,
  };
}

const COUPON_ERRORS: Record<string, string> = {
  invalid_code: 'That code is not valid.',
  coupon_expired: 'That code has expired.',
  coupon_used_up: 'That code has been fully used.',
  already_redeemed: 'You already used that code.',
  too_many_attempts: 'Too many tries. Wait 10 minutes and try again.',
};

export async function redeemCoupon(code: string): Promise<{ ok: boolean; message: string }> {
  const { data, error } = await supabase.rpc('redeem_coupon', { p_code: code });
  if (error) throw error;
  if (!data?.ok) return { ok: false, message: COUPON_ERRORS[data?.error as string] ?? 'Could not use that code.' };
  return { ok: true, message: String(data.message || 'Code applied.') };
}
