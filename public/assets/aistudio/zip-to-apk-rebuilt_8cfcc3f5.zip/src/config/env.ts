/* Runtime configuration. Everything can be overridden with VITE_* variables, so the same
   code works for local development, the Android build and any web host. */

const env = import.meta.env;
const text = (value: unknown): string => (typeof value === 'string' ? value.trim() : '');

export const SUPABASE_URL = text(env.VITE_SUPABASE_URL) || 'https://lggwgzvfptzpvihdzgir.supabase.co';
// Publishable (anon) key: designed to be public. Row level security protects the data.
export const SUPABASE_ANON_KEY = text(env.VITE_SUPABASE_ANON_KEY) || 'sb_publishable_4WZfD5K2IBJtJRhzI-Y8Eg_xprsqXwf';

/** The deployed Cloudflare Worker that starts builds. Set the WORKER_URL repository variable. */
export const WORKER_URL = text(env.VITE_WORKER_URL).replace(/\/+$/, '');
export const WORKER_CONFIGURED = /^https:\/\/[^\s/]+/i.test(WORKER_URL);

/** Web and PWA users have no AdMob, so a clearly labelled demo ad can stand in. */
export const WEB_DEMO_ADS = text(env.VITE_WEB_DEMO_ADS) !== 'false';

export const ADS_PER_CREDIT = 2;
export const MAX_UPLOAD_BYTES = 50 * 1024 * 1024; // matches the Supabase "uploads" bucket limit
export const BUILD_POLL_MS = 5000;
export const BUILD_TIMEOUT_MS = 20 * 60 * 1000;
