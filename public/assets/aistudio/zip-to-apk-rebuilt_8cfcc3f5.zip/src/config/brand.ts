export const APP_NAME = 'Zip to APK';
export const APP_TAGLINE = 'Turn a zipped web project into an Android app.';
export const APP_VERSION: string = typeof __APP_VERSION__ === 'string' ? __APP_VERSION__ : '0.0.0';
/** Prefix for everything this app writes to localStorage. */
export const STORAGE_PREFIX = 'zipapk';
