/* AdMob configuration. The App ID is also written into AndroidManifest.xml by the build workflow. */

const env = import.meta.env;
const pick = (value: string | undefined, fallback: string) => (value && value.trim() ? value.trim() : fallback);

export const ADMOB_APP_ID = pick(env.VITE_ADMOB_APP_ID, 'ca-app-pub-8824526919081671~3190339268');

export const AD_UNITS = {
  banner: pick(env.VITE_ADMOB_BANNER, 'ca-app-pub-8824526919081671/5133976329'),
  interstitial: pick(env.VITE_ADMOB_INTERSTITIAL, 'ca-app-pub-8824526919081671/6547875200'),
  rewarded: pick(env.VITE_ADMOB_REWARDED, 'ca-app-pub-8824526919081671/5972415277'),
} as const;

// Development always uses Google's test ads. Release builds use live ads unless VITE_ADMOB_TESTING=true.
// Never tap your own live ads: add your phone's test device id below.
export const ADMOB_TESTING: boolean = !env.PROD || env.VITE_ADMOB_TESTING === 'true';
export const TEST_DEVICE_IDS: string[] = [];
