export type Plan = 'free' | 'pro' | 'developer';

export interface Profile {
  plan: Plan;
  credits: number;
  adViews: number;
  adProgress: number;
}

export type JobStatus = 'queued' | 'building' | 'done' | 'failed';

/** One row of public.build_jobs, as the app is allowed to read it. */
export interface BuildRow {
  id: string;
  status: JobStatus;
  app_name: string;
  package_id: string;
  version_name: string;
  error: string | null;
  apk_path: string | null;
  created_at: string;
  finished_at: string | null;
}

export type Orientation = 'portrait' | 'landscape' | 'sensor' | 'unspecified';
export type StatusBarStyle = 'default' | 'light' | 'dark';
export type MinSdk = 24 | 26 | 28 | 30;

export interface Permission {
  /** Android name without the "android.permission." prefix. */
  android: string;
  name: string;
  description: string;
  dangerous: boolean;
  category: string;
}

export interface DeepLink {
  scheme: string;
  host: string;
  pathPrefix: string;
}

export interface AppSettings {
  appName: string;
  packageId: string;
  versionName: string;
  primaryColor: string;
  orientation: Orientation;
  statusBar: StatusBarStyle;
  /** A 512 px PNG data URL made from the picked image. */
  logoDataUrl?: string;
  minSdk: MinSdk;
  /** Selected Android permission names. */
  permissions: string[];
  deepLinks: DeepLink[];
  mixedContent: boolean;
  webDebugging: boolean;
}

export type SourceKind = 'upload' | 'link';

export interface SourceInfo {
  kind: SourceKind;
  fileName?: string;
  fileSize?: number;
  url?: string;
}

export type ProjectStatus = 'draft' | 'building' | 'completed' | 'failed' | 'archived';

export interface BuildRecord {
  id: string;
  status: 'completed' | 'failed';
  at: number;
  error?: string;
}

export interface Project {
  id: string;
  name: string;
  source: SourceInfo;
  settings: AppSettings;
  status: ProjectStatus;
  createdAt: number;
  updatedAt: number;
  builds: BuildRecord[];
}
