import type { ReactNode } from 'react';
import { cx } from '@/lib/format';
import { routeHref, type RouteName } from '@/lib/router';
import { useSession } from '@/lib/session';
import { Icon, type IconName } from './Icon';
import { Logo } from './Logo';

const NAV: Array<{ name: RouteName; label: string; icon: IconName; primary?: boolean }> = [
  { name: 'home', label: 'Home', icon: 'home' },
  { name: 'build', label: 'Build', icon: 'plus', primary: true },
  { name: 'projects', label: 'Projects', icon: 'layers' },
  { name: 'settings', label: 'Settings', icon: 'settings' },
];

/** Top bar, bottom tab bar on phones, side rail on wide screens. */
export function Shell({ current, children }: { current: RouteName | null; children: ReactNode }) {
  const { profile, paid, plan } = useSession();
  return (
    <div className="app">
      <header className="topbar">
        <a className="brand" href={routeHref('home')} aria-label="Zip to APK home">
          <Logo size={28} />
          <span>Zip to APK</span>
        </a>
        {profile && (
          <a className="chip" href={routeHref('home')} title="Build credits">
            <Icon name="bolt" size={15} />
            {paid ? (plan === 'developer' ? 'Developer' : 'Pro') : `${profile.credits} credit${profile.credits === 1 ? '' : 's'}`}
          </a>
        )}
      </header>

      <nav className="nav" aria-label="Main">
        {NAV.map((item) => (
          <a
            key={item.name}
            href={routeHref(item.name)}
            className={cx('nav-item', item.primary && 'nav-primary', current === item.name && 'is-active')}
            aria-current={current === item.name ? 'page' : undefined}
          >
            <Icon name={item.icon} size={item.primary ? 22 : 20} />
            <span>{item.label}</span>
          </a>
        ))}
      </nav>

      <main className="main" id="main">
        {children}
      </main>
    </div>
  );
}
