import { useEffect, useRef, useState } from 'react';
import { registerDemoAdHost, type DemoAdRequest } from '@/services/ads';

/** Full-screen stand-in for a rewarded ad on the web. Always labelled as a demo. */
export function DemoAdOverlay() {
  const [req, setReq] = useState<DemoAdRequest | null>(null);
  const [left, setLeft] = useState(0);
  const active = useRef<DemoAdRequest | null>(null);

  useEffect(() => {
    registerDemoAdHost((r) => {
      active.current = r;
      setReq(r);
      setLeft(r?.seconds ?? 0);
    });
    return () => registerDemoAdHost(null);
  }, []);

  useEffect(() => {
    if (!req) return;
    const timer = window.setInterval(() => setLeft((s) => s - 1), 1000);
    return () => window.clearInterval(timer);
  }, [req]);

  useEffect(() => {
    if (req && left <= 0) close(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [left, req]);

  function close(finished: boolean) {
    const r = active.current;
    active.current = null;
    setReq(null);
    r?.resolve(finished);
  }

  if (!req) return null;
  return (
    <div className="ad-overlay" role="dialog" aria-modal="true" aria-label="Demo ad">
      <p className="badge badge-warn">Demo ad</p>
      <h2>{req.title}</h2>
      <p className="muted">Closes in {Math.max(left, 0)} seconds</p>
      <button className="btn btn-secondary" onClick={() => close(false)}>
        Close early
      </button>
    </div>
  );
}
