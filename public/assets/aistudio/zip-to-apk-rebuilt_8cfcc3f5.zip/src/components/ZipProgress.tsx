/* Progress shown as a zipper closing: open teeth ahead of the pull tab, interlocked teeth behind it. */

interface Props {
  value: number;
  label: string;
  tone?: 'ok' | 'bad';
}

export function ZipProgress({ value, label, tone }: Props) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div
      className="zip"
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(v)}
      data-tone={tone}
    >
      <div className="zip-fill" style={{ width: `${v}%` }} />
      <div className="zip-pull" style={{ left: `${v}%` }} />
    </div>
  );
}
