import type { JobStatus, ProjectStatus } from '@/types';

const JOB: Record<JobStatus, [string, string]> = {
  queued: ['Queued', 'badge-info'],
  building: ['Building', 'badge-info'],
  done: ['Ready', 'badge-ok'],
  failed: ['Failed', 'badge-bad'],
};

const PROJECT: Record<ProjectStatus, [string, string]> = {
  draft: ['Draft', 'badge-neutral'],
  building: ['Building', 'badge-info'],
  completed: ['Built', 'badge-ok'],
  failed: ['Failed', 'badge-bad'],
  archived: ['Archived', 'badge-neutral'],
};

export function JobBadge({ status }: { status: JobStatus }) {
  const [label, cls] = JOB[status] ?? [status, 'badge-neutral'];
  return <span className={`badge ${cls}`}>{label}</span>;
}

export function ProjectBadge({ status }: { status: ProjectStatus }) {
  const [label, cls] = PROJECT[status] ?? [status, 'badge-neutral'];
  return <span className={`badge ${cls}`}>{label}</span>;
}
