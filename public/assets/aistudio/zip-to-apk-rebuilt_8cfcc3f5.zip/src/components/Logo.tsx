/* The brand mark: a zip archive with a yellow pull tab. Matches the launcher icon. */

export function Logo({ size = 32 }: { size?: number }) {
  const teeth = Array.from({ length: 9 }, (_, i) => (
    <g key={i}>
      <rect x="486" y={296 + i * 36} width="26" height="20" rx="4" fill="#2B44FF" />
      <rect x="512" y={314 + i * 36} width="26" height="20" rx="4" fill="#1626C4" />
    </g>
  ));
  return (
    <svg width={size} height={size} viewBox="0 0 1024 1024" role="img" aria-label="Zip to APK">
      <defs>
        <linearGradient id="logo-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#4A63FF" />
          <stop offset="1" stopColor="#1626C4" />
        </linearGradient>
      </defs>
      <rect width="1024" height="1024" rx="228" fill="url(#logo-g)" />
      <rect x="332" y="262" width="360" height="500" rx="48" fill="#fff" />
      {teeth}
      <rect x="476" y="600" width="72" height="68" rx="18" fill="#FFC72C" />
      <rect x="490" y="650" width="44" height="96" rx="22" fill="#FFC72C" />
      <circle cx="512" cy="704" r="11" fill="#fff" />
    </svg>
  );
}
