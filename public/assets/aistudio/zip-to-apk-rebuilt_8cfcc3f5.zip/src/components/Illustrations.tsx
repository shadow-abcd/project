/* Small decorative SVGs for empty states and the welcome screen. Colours come from CSS variables. */

export function EmptyBuilds() {
  return (
    <svg width="132" height="96" viewBox="0 0 132 96" fill="none" aria-hidden="true">
      <rect x="14" y="20" width="62" height="66" rx="10" fill="var(--surface)" stroke="var(--line-strong)" strokeWidth="2" />
      <path d="M45 20v34" stroke="var(--brand)" strokeWidth="4" strokeDasharray="5 5" />
      <rect x="39" y="52" width="12" height="14" rx="4" fill="var(--tape)" />
      <rect x="86" y="30" width="34" height="56" rx="8" fill="var(--brand-soft)" stroke="var(--brand)" strokeWidth="2" />
      <rect x="95" y="36" width="16" height="3" rx="1.5" fill="var(--brand)" />
      <path d="M80 58h-6m0 0 4-4m-4 4 4 4" stroke="var(--muted)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function EmptyProjects() {
  return (
    <svg width="132" height="96" viewBox="0 0 132 96" fill="none" aria-hidden="true">
      <rect x="20" y="30" width="84" height="54" rx="10" fill="var(--surface)" stroke="var(--line-strong)" strokeWidth="2" />
      <path d="M20 44h84" stroke="var(--line-strong)" strokeWidth="2" />
      <rect x="32" y="16" width="40" height="22" rx="8" fill="var(--brand-soft)" stroke="var(--brand)" strokeWidth="2" />
      <rect x="34" y="56" width="36" height="5" rx="2.5" fill="var(--line-strong)" />
      <rect x="34" y="67" width="22" height="5" rx="2.5" fill="var(--line)" />
      <circle cx="98" cy="70" r="14" fill="var(--tape)" />
      <path d="M98 63v14M91 70h14" stroke="var(--tape-ink)" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

/** A horizontal zipper, used as the welcome-screen divider. */
export function ZipperRule() {
  const teeth = Array.from({ length: 28 }, (_, i) => i);
  return (
    <svg className="zipper-rule" viewBox="0 0 560 34" preserveAspectRatio="xMinYMid meet" fill="none" aria-hidden="true">
      {teeth.map((i) => (
        <g key={i}>
          <rect x={i * 16} y={i < 19 ? 12 : 3} width="9" height="10" rx="2.5" fill={i < 19 ? 'var(--brand)' : 'var(--line-strong)'} />
          <rect x={i * 16 + 8} y={i < 19 ? 12 : 21} width="9" height="10" rx="2.5" fill={i < 19 ? 'var(--brand-deep)' : 'var(--line-strong)'} />
        </g>
      ))}
      <rect x="296" y="4" width="30" height="26" rx="8" fill="var(--tape)" />
      <circle cx="311" cy="17" r="4" fill="var(--bg)" />
    </svg>
  );
}
