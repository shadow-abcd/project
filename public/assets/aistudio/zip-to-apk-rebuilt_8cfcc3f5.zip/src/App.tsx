import { useEffect } from 'react';
import { DemoAdOverlay } from '@/components/DemoAdOverlay';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { Logo } from '@/components/Logo';
import { Shell } from '@/components/Shell';
import { ToastHost } from '@/components/ToastHost';
import { APP_NAME } from '@/config/brand';
import { isNative } from '@/lib/platform';
import { navigate, useRoute, type RouteName } from '@/lib/router';
import { SessionProvider, useSession } from '@/lib/session';
import { hideBanner, showBanner } from '@/services/ads';
import Auth from '@/pages/Auth';
import BuildWizard from '@/pages/build/BuildWizard';
import Home from '@/pages/Home';
import Projects from '@/pages/Projects';
import Settings from '@/pages/Settings';
import Welcome from '@/pages/Welcome';

const TITLES: Record<RouteName, string> = {
  welcome: APP_NAME,
  auth: 'Sign in',
  home: 'Home',
  build: 'New build',
  projects: 'Projects',
  settings: 'Settings',
};

function Router() {
  const { loading, user, profile, paid } = useSession();
  const route = useRoute();

  // The banner belongs to the free plan only.
  useEffect(() => {
    if (user && profile && !paid) void showBanner();
    else void hideBanner();
  }, [user, profile, paid]);

  const signedInRoute: RouteName | null =
    route.name && route.name !== 'welcome' && route.name !== 'auth' ? route.name : null;

  // Signed-in people never sit on the welcome or sign-in screens.
  useEffect(() => {
    if (user && !signedInRoute) navigate('home', undefined, true);
  }, [user, signedInRoute]);

  useEffect(() => {
    const name = user ? signedInRoute ?? 'home' : route.name === 'auth' || isNative ? 'auth' : 'welcome';
    document.title = name === 'welcome' ? APP_NAME : `${TITLES[name]} · ${APP_NAME}`;
    window.scrollTo({ top: 0 });
  }, [user, signedInRoute, route.name]);

  if (loading) {
    return (
      <div className="welcome center" style={{ paddingTop: '30vh' }} aria-busy="true">
        <Logo size={64} />
      </div>
    );
  }

  if (!user) {
    if (route.name === 'auth' || isNative) return <Auth initialMode={route.params.get('mode') === 'signup' ? 'signup' : 'signin'} />;
    return <Welcome />;
  }

  const current = signedInRoute ?? 'home';
  return (
    <Shell current={current}>
      {current === 'home' && <Home />}
      {current === 'build' && <BuildWizard
          key={`${route.params.get('project') ?? 'new'}:${route.params.get('fresh') ?? ''}`}
          projectId={route.params.get('project')}
        />}
      {current === 'projects' && <Projects />}
      {current === 'settings' && <Settings />}
    </Shell>
  );
}

export default function App() {
  // Tells the startup safety net in index.html that the app is running.
  useEffect(() => {
    if (window.__zipapkBoot) window.__zipapkBoot.mounted = true;
  }, []);

  return (
    <ErrorBoundary>
      <SessionProvider>
        <Router />
        <ToastHost />
        <DemoAdOverlay />
      </SessionProvider>
    </ErrorBoundary>
  );
}
