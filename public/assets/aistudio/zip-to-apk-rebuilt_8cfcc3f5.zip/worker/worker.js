/* =====================================================================
   Cloudflare Worker: the build service for Zip to APK.

   Users never see a GitHub token or a Supabase service key. Those live here as
   encrypted Worker secrets.

   Routes
     POST /build              start a build (the signed-in user's Supabase token)
     POST /callback/:jobId    the build server reports progress or sends the APK
     GET  /health             status check
   Cron (every 10 minutes)    fails builds that stopped reporting and returns their credit

   NEVER paste keys or tokens into this file. Put them in the Worker secrets below.

   Secrets (Settings > Variables and Secrets > Secret):
     SUPABASE_SERVICE_ROLE_KEY   service role key
     GITHUB_TOKEN                fine-grained token: Actions (read and write) on the builder repo only
   Variables (plain text):
     SUPABASE_URL                https://<project>.supabase.co
     SUPABASE_ANON_KEY           sb_publishable_...  (the same key the app uses)
     GITHUB_REPO                 owner/repo that holds .github/workflows/build.yml
     GITHUB_REF                  branch with the workflow (optional, default main)
     WORKFLOW_FILE               build.yml (optional)
     PUBLIC_WORKER_URL           this Worker's https URL (optional, default = request origin)
   ===================================================================== */

const CORS = {
  'Access-Control-Allow-Origin': '*', // the app authenticates with a Bearer token, not cookies
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
  'Access-Control-Max-Age': '86400',
};

const MAX_APK_BYTES = 150 * 1024 * 1024;
const MIN_APK_BYTES = 1024;
const MAX_BODY_BYTES = 64 * 1024;
const MAX_OPEN_JOBS_PER_USER = 3;
const STALE_AFTER_MINUTES = 45; // the workflow itself times out after 30
const PKG_RE = /^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/;
const VER_RE = /^[0-9A-Za-z._-]{1,20}$/;

// Words the Java compiler reserves. A package segment using one fails the Android build.
const JAVA_KEYWORDS = new Set(
  ('abstract assert boolean break byte case catch char class const continue default do double else enum extends ' +
    'final finally float for goto if implements import instanceof int interface long native new package private ' +
    'protected public return short static strictfp super switch synchronized this throw throws transient try void ' +
    'volatile while true false null _').split(' '),
);

// Keep in sync with src/data/permissions.ts. Anything else is dropped.
const ALLOWED_PERMISSIONS = new Set([
  'INTERNET', 'ACCESS_NETWORK_STATE', 'ACCESS_WIFI_STATE', 'NEARBY_WIFI_DEVICES', 'CAMERA', 'RECORD_AUDIO',
  'MODIFY_AUDIO_SETTINGS', 'VIBRATE', 'FLASHLIGHT', 'NFC', 'BLUETOOTH_CONNECT', 'BLUETOOTH_SCAN',
  'ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'ACCESS_BACKGROUND_LOCATION', 'READ_MEDIA_IMAGES',
  'READ_MEDIA_VIDEO', 'READ_MEDIA_AUDIO', 'READ_EXTERNAL_STORAGE', 'WRITE_EXTERNAL_STORAGE', 'POST_NOTIFICATIONS',
  'WAKE_LOCK', 'RECEIVE_BOOT_COMPLETED', 'FOREGROUND_SERVICE', 'USE_BIOMETRIC', 'READ_CONTACTS', 'READ_CALENDAR',
  'CALL_PHONE',
]);
const ORIENTATIONS = new Set(['portrait', 'landscape', 'sensor', 'unspecified']);
const STATUS_BARS = new Set(['default', 'light', 'dark']);
const MIN_SDKS = new Set([24, 26, 28, 30]);

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...CORS },
  });
}

function randomHex(bytes) {
  const a = new Uint8Array(bytes);
  crypto.getRandomValues(a);
  return [...a].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function sha256Hex(text) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Free users get a generated package name. Pro and Developer users may choose their own.
function defaultPackageId(userId) {
  return 'com.ziphtml.u' + userId.replace(/-/g, '').slice(0, 12);
}

function packageProblem(id) {
  if (!PKG_RE.test(id) || id.length > 100) return 'Package name looks wrong. Example: com.yourname.app';
  const reserved = id.split('.').find((part) => JAVA_KEYWORDS.has(part));
  if (reserved) return `"${reserved}" is a reserved word and cannot be used in a package name.`;
  return null;
}

// Supabase rejects a publishable/secret (sb_...) key sent in BOTH the apikey and Authorization
// headers ("Invalid JWT"). Send sb_ keys in apikey only. Legacy JWT keys still need Authorization.
function serviceAuthHeaders(env) {
  const key = env.SUPABASE_SERVICE_ROLE_KEY;
  const h = { apikey: key };
  if (!key.startsWith('sb_')) h.Authorization = `Bearer ${key}`;
  return h;
}

function serviceHeaders(env) {
  return { ...serviceAuthHeaders(env), 'Content-Type': 'application/json' };
}

function db(env, path, init = {}) {
  return fetch(`${env.SUPABASE_URL}/rest/v1/${path}`, {
    ...init,
    headers: { ...serviceHeaders(env), ...(init.headers || {}) },
  });
}

// Ask Supabase who the caller is. Never trust a user id sent in the body.
async function getUser(env, auth) {
  const r = await fetch(`${env.SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: env.SUPABASE_ANON_KEY, Authorization: auth },
  });
  if (!r.ok) return null;
  const u = await r.json().catch(() => null);
  return u && u.id ? u : null;
}

async function refundCredit(env, userId) {
  await fetch(`${env.SUPABASE_URL}/rest/v1/rpc/refund_credit`, {
    method: 'POST',
    headers: serviceHeaders(env),
    body: JSON.stringify({ p_user: userId }),
  });
}

// Update a job only while it is still open. Returns true if this call changed it.
async function patchJob(env, jobId, fields, fromStatuses) {
  const filter = `id=eq.${jobId}&status=in.(${fromStatuses.join(',')})`;
  const r = await db(env, `build_jobs?${filter}`, {
    method: 'PATCH',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify(fields),
  });
  const rows = await r.json().catch(() => []);
  return Array.isArray(rows) && rows.length > 0;
}

// Mark a job failed and give the credit back (once, and only if it was charged).
async function failJob(env, job, message) {
  const changed = await patchJob(
    env,
    job.id,
    { status: 'failed', error: message, finished_at: new Date().toISOString() },
    ['queued', 'building'],
  );
  if (changed && job.charged) await refundCredit(env, job.user_id);
  return changed;
}

/* ---------------------------------------------------------------------
   Input cleaning
   --------------------------------------------------------------------- */

function cleanAppName(value) {
  // eslint-disable-next-line no-control-regex
  const s = String(value || '').replace(/[\u0000-\u001f\u007f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 40);
  return s || 'App';
}

const PRIVATE_HOST = /^(localhost|.*\.local|.*\.internal|0\.0\.0\.0|\[.*\]|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.)/i;

function checkSourceUrl(raw) {
  if (typeof raw !== 'string' || raw.length > 2048) return { error: 'Invalid ZIP URL.' };
  let url;
  try {
    url = new URL(raw);
  } catch (_) {
    return { error: 'Invalid ZIP URL.' };
  }
  if (url.protocol !== 'https:') return { error: 'The ZIP URL must use https.' };
  if (url.username || url.password) return { error: 'The ZIP URL must not contain a username or password.' };
  if (PRIVATE_HOST.test(url.hostname) || !url.hostname.includes('.')) {
    return { error: 'The ZIP URL must be a public address.' };
  }
  return { url };
}

/* Keeps only values the build is prepared to apply. Unknown or malformed fields are dropped,
   so a hand-made request cannot add permissions, hosts or URLs the UI never offers. */
function cleanConfig(raw, env) {
  const c = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
  const out = {};

  if (ORIENTATIONS.has(c.orientation)) out.orientation = c.orientation;
  if (STATUS_BARS.has(c.statusBar)) out.statusBar = c.statusBar;
  if (typeof c.primaryColor === 'string' && /^#[0-9a-fA-F]{6}$/.test(c.primaryColor)) out.primaryColor = c.primaryColor.toUpperCase();
  if (MIN_SDKS.has(c.minSdk)) out.minSdk = c.minSdk;
  if (typeof c.mixedContent === 'boolean') out.mixedContent = c.mixedContent;
  if (typeof c.webDebugging === 'boolean') out.webDebugging = c.webDebugging;

  if (Array.isArray(c.permissions)) {
    out.permissions = [...new Set(c.permissions.filter((p) => typeof p === 'string' && ALLOWED_PERMISSIONS.has(p)))];
  }

  if (Array.isArray(c.deepLinks)) {
    out.deepLinks = c.deepLinks
      .slice(0, 5)
      .map((d) => ({
        scheme: String((d && d.scheme) || '').trim().toLowerCase(),
        host: String((d && d.host) || '').trim().toLowerCase(),
        pathPrefix: String((d && d.pathPrefix) || '').trim(),
      }))
      .filter(
        (d) =>
          /^[a-z][a-z0-9+.-]{0,30}$/.test(d.scheme) &&
          /^[a-z0-9*.-]{0,100}$/.test(d.host) &&
          (d.scheme === 'http' || d.scheme === 'https' ? d.host !== '' : true) &&
          (d.pathPrefix === '' || /^\/[A-Za-z0-9._~!$&'()*+,;=:@%/-]{0,100}$/.test(d.pathPrefix)),
      );
  }

  // The icon must be a signed link into this project's own "uploads" bucket.
  const iconPrefix = `${env.SUPABASE_URL}/storage/v1/object/sign/uploads/`;
  if (typeof c.iconUrl === 'string' && c.iconUrl.length <= 1800 && c.iconUrl.startsWith(iconPrefix)) out.iconUrl = c.iconUrl;

  return out;
}

/* ---------------------------------------------------------------------
   POST /build
   --------------------------------------------------------------------- */
async function handleBuild(request, env, origin) {
  const auth = request.headers.get('Authorization') || '';
  if (!auth.startsWith('Bearer ')) return json({ error: 'Please sign in again.' }, 401);

  const length = Number(request.headers.get('Content-Length') || 0);
  if (length > MAX_BODY_BYTES) return json({ error: 'The request is too large.' }, 413);

  const user = await getUser(env, auth);
  if (!user) return json({ error: 'Please sign in again.' }, 401);

  let body;
  try {
    body = await request.json();
  } catch (_) {
    return json({ error: 'Invalid request.' }, 400);
  }
  if (!body || typeof body !== 'object') return json({ error: 'Invalid request.' }, 400);

  const source = checkSourceUrl(body.zipUrl);
  if (source.error) return json({ error: source.error }, 400);

  const appName = cleanAppName(body.appName);
  const versionName = String(body.versionName || '1.0.0').trim();
  if (!VER_RE.test(versionName)) {
    return json({ error: 'Version may use letters, numbers, dots, dashes and underscores.' }, 400);
  }
  const versionCode = Number.isInteger(body.versionCode) ? Math.min(Math.max(body.versionCode, 1), 2100000000) : 1;

  // Plan decides what the user may change
  const pr = await db(env, `profiles?id=eq.${user.id}&select=plan`);
  const [prof] = await pr.json().catch(() => []);
  if (!prof) return json({ error: 'Your profile is missing. Run supabase/setup.sql in Supabase.' }, 500);
  const plan = prof.plan;

  let packageId = defaultPackageId(user.id);
  const wanted = String(body.packageId || '').trim().toLowerCase();
  if (wanted) {
    if (plan === 'free') {
      return json({ error: 'Custom package names are a Pro and Developer feature.', code: 'pro_only' }, 403);
    }
    const problem = packageProblem(wanted);
    if (problem) return json({ error: problem }, 400);
    packageId = wanted;
  }

  // Cap parallel builds per person so one account cannot drain the build minutes.
  const open = await db(env, `build_jobs?user_id=eq.${user.id}&status=in.(queued,building)&select=id&limit=${MAX_OPEN_JOBS_PER_USER}`);
  const openJobs = await open.json().catch(() => []);
  if (Array.isArray(openJobs) && openJobs.length >= MAX_OPEN_JOBS_PER_USER) {
    return json({ error: 'You already have builds running. Wait for one to finish, then try again.', code: 'busy' }, 429);
  }

  const config = cleanConfig(body.config, env);

  // Charge one credit (Pro and Developer are not charged). Runs as this user.
  const rpc = await fetch(`${env.SUPABASE_URL}/rest/v1/rpc/consume_credit`, {
    method: 'POST',
    headers: { apikey: env.SUPABASE_ANON_KEY, Authorization: auth, 'Content-Type': 'application/json' },
    body: '{}',
  });
  if (!rpc.ok) {
    const text = await rpc.text();
    if (text.includes('no_credits')) {
      return json({ error: 'You have no build credits. Watch 2 ads to earn one.', code: 'no_credits' }, 402);
    }
    if (rpc.status === 401 || text.includes('not_authenticated')) {
      return json({ error: 'Please sign in again.' }, 401);
    }
    return json({ error: 'Could not check your credits. Try again.' }, 502);
  }
  const charge = await rpc.json();

  // Create the job row (the token is stored as a hash only)
  const token = randomHex(32);
  const ins = await db(env, 'build_jobs', {
    method: 'POST',
    headers: { Prefer: 'return=representation' },
    body: JSON.stringify({
      user_id: user.id,
      app_name: appName,
      package_id: packageId,
      version_name: versionName,
      version_code: versionCode,
      charged: !!charge.charged,
      token_hash: await sha256Hex(token),
    }),
  });
  const [job] = await ins.json().catch(() => []);
  if (!ins.ok || !job) {
    if (charge.charged) await refundCredit(env, user.id);
    return json({ error: 'Could not create the build. Your credit was returned.' }, 502);
  }

  // Start the GitHub workflow in the builder repo
  const workflow = env.WORKFLOW_FILE || 'build.yml';
  const dispatch = await fetch(`https://api.github.com/repos/${env.GITHUB_REPO}/actions/workflows/${workflow}/dispatches`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${env.GITHUB_TOKEN}`,
      Accept: 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      'Content-Type': 'application/json',
      'User-Agent': 'zip-to-apk-worker',
    },
    body: JSON.stringify({
      ref: env.GITHUB_REF || 'main',
      inputs: {
        job_id: job.id,
        zip_url: source.url.toString(),
        app_name: appName,
        package_id: packageId,
        version_name: versionName,
        version_code: String(versionCode),
        callback_base: env.PUBLIC_WORKER_URL || origin,
        callback_token: token,
        build_config: JSON.stringify(config),
      },
    }),
  });

  if (!dispatch.ok) {
    console.error('GitHub dispatch failed', dispatch.status, (await dispatch.text().catch(() => '')).slice(0, 300));
    await failJob(env, { id: job.id, user_id: user.id, charged: !!charge.charged }, 'The build server is busy or unavailable. Try again in a few minutes.');
    return json({ error: 'The build server is unavailable right now. Your credit was returned.', jobId: job.id }, 503);
  }

  return json({
    jobId: job.id,
    status: 'queued',
    plan,
    credits: charge.credits,
    packageId,
    message: 'Build queued. This usually takes a few minutes.',
  });
}

/* ---------------------------------------------------------------------
   POST /callback/:jobId  (called by the GitHub workflow)
     - application/json  {status: "building"} or {status: "failed", error}
     - anything else     the APK bytes
   --------------------------------------------------------------------- */
async function handleCallback(request, env, jobId) {
  if (!/^[0-9a-f-]{36}$/.test(jobId)) return json({ error: 'Not found' }, 404);

  const token = request.headers.get('X-Job-Token') || '';
  if (!/^[0-9a-f]{64}$/.test(token)) return json({ error: 'Unauthorized' }, 401);

  const r = await db(env, `build_jobs?id=eq.${jobId}&select=id,user_id,status,charged,token_hash`);
  const [job] = await r.json().catch(() => []);
  if (!job) return json({ error: 'Not found' }, 404);
  if ((await sha256Hex(token)) !== job.token_hash) return json({ error: 'Unauthorized' }, 401);
  if (job.status === 'done' || job.status === 'failed') return json({ ok: true, note: 'already finished' });

  const type = request.headers.get('Content-Type') || '';

  if (type.includes('application/json')) {
    const msg = await request.json().catch(() => ({}));
    if (msg.status === 'building') {
      await patchJob(env, jobId, { status: 'building' }, ['queued']);
      return json({ ok: true });
    }
    if (msg.status === 'failed') {
      await failJob(env, job, String(msg.error || 'The build failed.').slice(0, 500));
      return json({ ok: true });
    }
    return json({ error: 'Unknown status' }, 400);
  }

  // APK upload. Streamed straight to storage: a Worker has about 128 MB of memory, so a large
  // APK must never be buffered here.
  const size = Number(request.headers.get('Content-Length') || 0);
  if (!request.body || size < MIN_APK_BYTES || size > MAX_APK_BYTES) {
    await failJob(env, job, 'The build produced an invalid APK file.');
    return json({ error: 'Invalid APK' }, 400);
  }

  const path = `${job.user_id}/${jobId}.apk`;
  const up = await fetch(`${env.SUPABASE_URL}/storage/v1/object/apks/${path}`, {
    method: 'POST',
    headers: {
      ...serviceAuthHeaders(env),
      'Content-Type': 'application/vnd.android.package-archive',
      'Content-Length': String(size),
      'x-upsert': 'true',
    },
    body: request.body,
  });
  if (!up.ok) {
    console.error('APK storage failed', up.status, (await up.text().catch(() => '')).slice(0, 300));
    await failJob(env, job, 'The APK was built but could not be saved. Your credit was returned.');
    return json({ error: 'Storage error' }, 502);
  }

  await patchJob(env, jobId, { status: 'done', apk_path: path, error: null, finished_at: new Date().toISOString() }, ['queued', 'building']);
  return json({ ok: true });
}

/* ---------------------------------------------------------------------
   Cron: a build whose workflow was cancelled, timed out or crashed never calls back.
   Fail it after STALE_AFTER_MINUTES so the person is not left waiting and gets the credit back.
   --------------------------------------------------------------------- */
export async function reapStaleJobs(env) {
  const cutoff = encodeURIComponent(new Date(Date.now() - STALE_AFTER_MINUTES * 60 * 1000).toISOString());
  const r = await db(env, `build_jobs?status=in.(queued,building)&created_at=lt.${cutoff}&select=id,user_id,charged&limit=50`);
  const jobs = await r.json().catch(() => []);
  if (!Array.isArray(jobs)) return 0;
  let failed = 0;
  for (const job of jobs) {
    if (await failJob(env, job, 'The build timed out. If a credit was used, it has been returned.')) failed++;
  }
  return failed;
}

/* ---------------------------------------------------------------------
   Router
   --------------------------------------------------------------------- */
export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

    const url = new URL(request.url);

    if (request.method === 'GET' && url.pathname === '/health') {
      const configured = !!(env.SUPABASE_URL && env.SUPABASE_ANON_KEY && env.SUPABASE_SERVICE_ROLE_KEY && env.GITHUB_TOKEN && env.GITHUB_REPO);
      return json({ ok: true, configured });
    }

    if (request.method === 'POST' && url.pathname === '/build') {
      return handleBuild(request, env, url.origin);
    }

    const cb = url.pathname.match(/^\/callback\/([^/]+)$/);
    if (request.method === 'POST' && cb) {
      return handleCallback(request, env, cb[1]);
    }

    return json({ error: 'Not found' }, 404);
  },

  async scheduled(_event, env, ctx) {
    ctx.waitUntil(reapStaleJobs(env));
  },
};
