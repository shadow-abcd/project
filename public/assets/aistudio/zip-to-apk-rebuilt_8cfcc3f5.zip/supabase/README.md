# Database setup

Run these in the Supabase SQL editor, in this order, on a new project:

1. `setup.sql` creates profiles, credits, build jobs, coupons and their functions.
2. `migration_v2.sql` adds ad progress tracking.
3. `storage.sql` creates the private `uploads` and `apks` buckets and their access rules.
4. `add_coupon.sql` is a template for coupon codes. Edit it before you run it.

Every script is safe to run twice. If one fails, nothing from that script is kept, so fix the cause and run the same script again.

## Error: relation "storage.buckets" does not exist

Storage is not switched on for the project yet. Open **Storage** in the Supabase dashboard, wait until it loads, then run `storage.sql` again. If the Storage page itself shows an error, the project is still starting: wait a few minutes until its status says Healthy.

## Switch off the old public coupon

If an older `setup.sql` created a public master coupon, turn it off:

```sql
update public.coupons set active = false where code = 'FIRST ME';
```
