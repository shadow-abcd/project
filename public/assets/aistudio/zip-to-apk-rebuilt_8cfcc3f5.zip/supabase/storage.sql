-- Storage setup: the two private buckets and who may read and write them.
-- Run this AFTER setup.sql and migration_v2.sql.
--
-- If you get the message below, Supabase Storage has not been switched on for this project yet.
-- Open "Storage" in the left menu of the Supabase dashboard once, wait for the page to load,
-- then run this script again. It is safe to run more than once.

do $$
begin
  if to_regclass('storage.buckets') is null or to_regclass('storage.objects') is null then
    raise exception 'Storage is not ready yet. Open Storage in the Supabase dashboard, wait for it to load, then run this script again.';
  end if;
end
$$;

-- ---------- Buckets and access rules ----------
-- uploads: source ZIP/HTML from the studio (private, owner-only)
-- apks:    finished APKs (private, owner-only; the app uses signed download links)
insert into storage.buckets (id, name, public, file_size_limit)
values ('uploads', 'uploads', false, 52428800),
       ('apks',    'apks',    false, 209715200)
on conflict (id) do nothing;

drop policy if exists "owner uploads source" on storage.objects;
create policy "owner uploads source" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'uploads' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "owner reads source" on storage.objects;
create policy "owner reads source" on storage.objects
  for select to authenticated
  using (bucket_id = 'uploads' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "owner reads apk" on storage.objects;
create policy "owner reads apk" on storage.objects
  for select to authenticated
  using (bucket_id = 'apks' and (storage.foldername(name))[1] = auth.uid()::text);

-- Developer plan: set manually, e.g.
--   update public.profiles set plan = 'developer' where email = 'you@example.com';
