-- =====================================================================
-- Migration v2 — run ONCE after supabase/setup.sql (SQL Editor → Run).
-- Safe to run again.
--   • Plans: free | pro | developer
--   • Rewarded ads: 2 ads = 1 credit (was 1 ad = 1 credit)
--   • Build jobs, storage buckets, credit refunds for failed builds
-- =====================================================================

-- ---------- Plans ----------
alter table public.profiles drop constraint if exists profiles_plan_check;
alter table public.profiles add constraint profiles_plan_check
  check (plan in ('free', 'pro', 'developer'));

-- ---------- 2 ads = 1 credit ----------
-- ad_progress counts ads toward the next credit (0 or 1).
alter table public.profiles
  add column if not exists ad_progress integer not null default 0 check (ad_progress in (0, 1));

create or replace function public.record_ad_view()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  p   public.profiles;
  n   integer;
  earned boolean := false;
begin
  if uid is null then raise exception 'not_authenticated'; end if;

  select * into p from public.profiles where id = uid for update;
  if not found then raise exception 'no_profile'; end if;

  -- Pro and Developer accounts do not need ads
  if p.plan in ('pro', 'developer') then raise exception 'not_needed'; end if;

  if p.last_ad_view_at is not null and now() - p.last_ad_view_at < interval '25 seconds' then
    raise exception 'rate_limited';
  end if;

  select count(*) into n from public.ad_view_log
   where user_id = uid and viewed_at > now() - interval '24 hours';
  if n >= 30 then raise exception 'daily_limit'; end if;

  insert into public.ad_view_log (user_id) values (uid);

  if p.ad_progress = 0 then
    update public.profiles
       set ad_progress = 1, ad_views = ad_views + 1, last_ad_view_at = now()
     where id = uid returning * into p;
  else
    update public.profiles
       set ad_progress = 0, ad_views = ad_views + 1, credits = credits + 1, last_ad_view_at = now()
     where id = uid returning * into p;
    earned := true;
  end if;

  return jsonb_build_object(
    'credits', p.credits, 'ad_views', p.ad_views, 'ad_progress', p.ad_progress,
    'earned_credit', earned, 'ads_per_credit', 2
  );
end;
$$;

-- ---------- consume_credit: Pro and Developer are never charged ----------
create or replace function public.consume_credit()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  p   public.profiles;
begin
  if uid is null then raise exception 'not_authenticated'; end if;

  select * into p from public.profiles where id = uid for update;
  if not found then raise exception 'no_profile'; end if;

  if p.plan in ('pro', 'developer') then
    return jsonb_build_object('credits', p.credits, 'plan', p.plan, 'charged', false);
  end if;

  if p.credits < 1 then raise exception 'no_credits'; end if;

  update public.profiles set credits = credits - 1 where id = uid returning * into p;
  return jsonb_build_object('credits', p.credits, 'plan', p.plan, 'charged', true);
end;
$$;

-- Give a credit back when a build fails. Only the Worker (service role) can call it.
create or replace function public.refund_credit(p_user uuid)
returns void
language sql
security definer
set search_path = public
as $$
  update public.profiles set credits = credits + 1 where id = p_user;
$$;

revoke all on function public.refund_credit(uuid) from public, anon, authenticated;
grant execute on function public.refund_credit(uuid) to service_role;

-- ---------- Build jobs ----------
create table if not exists public.build_jobs (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid        not null references auth.users(id) on delete cascade,
  status        text        not null default 'queued'
                check (status in ('queued', 'building', 'done', 'failed')),
  app_name      text        not null,
  package_id    text        not null,
  version_name  text        not null default '1.0.0',
  version_code  integer     not null default 1,
  charged       boolean     not null default false,
  token_hash    text        not null,          -- sha256 of the callback token; never sent to the app
  apk_path      text,
  error         text,
  created_at    timestamptz not null default now(),
  finished_at   timestamptz
);

create index if not exists build_jobs_user_idx on public.build_jobs (user_id, created_at desc);

alter table public.build_jobs enable row level security;

drop policy if exists "read own builds" on public.build_jobs;
create policy "read own builds" on public.build_jobs
  for select to authenticated using (auth.uid() = user_id);

-- The app may read every column EXCEPT token_hash
revoke all on public.build_jobs from anon, authenticated;
grant select (id, user_id, status, app_name, package_id, version_name, version_code,
              charged, apk_path, error, created_at, finished_at)
  on public.build_jobs to authenticated;

-- Storage buckets and their access rules are in storage.sql.
