-- =====================================================================
-- Add / change coupon codes
-- Supabase Dashboard -> SQL Editor -> paste ONE of the examples (edit it) -> Run.
-- Codes are not case sensitive for the user, but store them in UPPERCASE here.
-- =====================================================================

-- 1) 10 extra build credits, each user once, anyone can use it, never expires
insert into public.coupons (code, kind, value, max_uses, note)
values ('WELCOME10', 'credits', 10, null, 'Welcome bonus');

-- 2) Pro plan, only the first 50 people, expires on 31 Dec 2026
-- insert into public.coupons (code, kind, max_uses, expires_at, note)
-- values ('LAUNCH50', 'pro', 50, '2026-12-31 23:59:59+00', 'Launch promo');

-- 3) Turn a code off (or back on)
-- update public.coupons set active = false where code = 'WELCOME10';

-- 4) See all codes and how often they were used
-- select code, kind, value, uses, max_uses, expires_at, active from public.coupons order by created_at;

-- 5) Remove a user's Pro plan
-- update public.profiles set plan = 'free' where email = 'someone@example.com';
