-- =====================================================================
-- Zip & HTML to APK Converter — Supabase setup
-- Run once: Supabase Dashboard → SQL Editor → New query → paste → Run.
-- Safe to run again.
-- =====================================================================

-- ---------- Tables ----------

create table if not exists public.profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  email           text,
  plan            text        not null default 'free' check (plan in ('free', 'pro')),
  credits         integer     not null default 1 check (credits >= 0),
  ad_views        integer     not null default 0,
  last_ad_view_at timestamptz,
  created_at      timestamptz not null default now()
);

create table if not exists public.ad_view_log (
  id        bigserial primary key,
  user_id   uuid        not null references auth.users(id) on delete cascade,
  viewed_at timestamptz not null default now()
);

create index if not exists ad_view_log_user_time_idx on public.ad_view_log (user_id, viewed_at desc);

-- ---------- Row level security ----------
-- Users may READ their own profile. Nobody can write to these tables directly:
-- credits and plan only change through the functions below (or the service role).

alter table public.profiles    enable row level security;
alter table public.ad_view_log enable row level security;

drop policy if exists "read own profile" on public.profiles;
create policy "read own profile" on public.profiles
  for select to authenticated
  using (auth.uid() = id);

-- ---------- Create a profile for every new user ----------

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email)
  values (new.id, new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Backfill users that signed up before this script existed
insert into public.profiles (id, email)
select id, email from auth.users
on conflict (id) do nothing;

-- ---------- record_ad_view(): +1 credit after a rewarded ad ----------
-- Limits: at least 25 seconds between ads, at most 30 ads per 24 hours.

create or replace function public.record_ad_view()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  p   public.profiles;
  n   integer;
begin
  if uid is null then
    raise exception 'not_authenticated';
  end if;

  select * into p from public.profiles where id = uid for update;
  if not found then
    raise exception 'no_profile';
  end if;

  if p.last_ad_view_at is not null and now() - p.last_ad_view_at < interval '25 seconds' then
    raise exception 'rate_limited';
  end if;

  select count(*) into n
  from public.ad_view_log
  where user_id = uid and viewed_at > now() - interval '24 hours';
  if n >= 30 then
    raise exception 'daily_limit';
  end if;

  insert into public.ad_view_log (user_id) values (uid);

  update public.profiles
     set credits         = credits + 1,
         ad_views        = ad_views + 1,
         last_ad_view_at = now()
   where id = uid
   returning * into p;

  return jsonb_build_object('credits', p.credits, 'ad_views', p.ad_views);
end;
$$;

-- ---------- consume_credit(): -1 credit per build (Pro plan is not charged) ----------
-- The Cloudflare Worker calls this with the user's own access token.

create or replace function public.consume_credit()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid uuid := auth.uid();
  p   public.profiles;
begin
  if uid is null then
    raise exception 'not_authenticated';
  end if;

  select * into p from public.profiles where id = uid for update;
  if not found then
    raise exception 'no_profile';
  end if;

  if p.plan = 'pro' then
    return jsonb_build_object('credits', p.credits, 'plan', p.plan);
  end if;

  if p.credits < 1 then
    raise exception 'no_credits';
  end if;

  update public.profiles set credits = credits - 1 where id = uid returning * into p;
  return jsonb_build_object('credits', p.credits, 'plan', p.plan);
end;
$$;

-- ---------- Who may call the functions ----------

revoke all on function public.record_ad_view()  from public, anon;
revoke all on function public.consume_credit()  from public, anon;
grant execute on function public.record_ad_view() to authenticated;
grant execute on function public.consume_credit() to authenticated;

-- To make someone Pro (run manually, replace the email):
--   update public.profiles set plan = 'pro' where email = 'someone@example.com';

-- =====================================================================
-- COUPON CODES
-- Codes live only in the database (the app never contains them) and are redeemed through
-- redeem_coupon(). Nobody can list or read them from the app.
--
--   kind = 'pro'      -> the user's plan becomes Pro (unlimited builds)
--   kind = 'credits'  -> the user gets `value` extra build credits
--   max_uses = NULL   -> the code can be used by any number of different users
--   Each user can redeem a given code once.
--
-- Add more codes later: see supabase/add_coupon.sql
-- =====================================================================

create table if not exists public.coupons (
  code       text primary key,                       -- stored UPPERCASE, single spaces
  kind       text        not null check (kind in ('pro', 'credits')),
  value      integer     not null default 0 check (value >= 0),
  max_uses   integer     check (max_uses is null or max_uses > 0),
  uses       integer     not null default 0,
  expires_at timestamptz,
  active     boolean     not null default true,
  note       text,
  created_at timestamptz not null default now()
);

create table if not exists public.coupon_redemptions (
  id          bigserial primary key,
  user_id     uuid        not null references auth.users(id) on delete cascade,
  code        text        not null references public.coupons(code) on delete cascade,
  redeemed_at timestamptz not null default now(),
  unique (user_id, code)
);

create table if not exists public.coupon_attempts (
  id           bigserial primary key,
  user_id      uuid        not null references auth.users(id) on delete cascade,
  attempted_at timestamptz not null default now()
);
create index if not exists coupon_attempts_user_time_idx on public.coupon_attempts (user_id, attempted_at desc);

-- RLS on, no policies: the tables cannot be read or changed from the app.
alter table public.coupons            enable row level security;
alter table public.coupon_redemptions enable row level security;
alter table public.coupon_attempts    enable row level security;

-- No coupon is created here on purpose. A Pro code with unlimited uses that is written into a script
-- anyone can read would hand the Pro plan to everyone. Create your own codes in the Supabase SQL
-- editor instead (see add_coupon.sql), and always give them a use limit or an expiry date.

create or replace function public.redeem_coupon(p_code text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  uid     uuid := auth.uid();
  norm    text := upper(regexp_replace(btrim(coalesce(p_code, '')), '\s+', ' ', 'g'));
  c       public.coupons;
  p       public.profiles;
  recent  integer;
  msg     text;
begin
  if uid is null then
    raise exception 'not_authenticated';
  end if;

  -- Throttle guessing: at most 10 attempts per 10 minutes
  select count(*) into recent
  from public.coupon_attempts
  where user_id = uid and attempted_at > now() - interval '10 minutes';
  if recent >= 10 then
    return jsonb_build_object('ok', false, 'error', 'too_many_attempts');
  end if;
  insert into public.coupon_attempts (user_id) values (uid);

  select * into p from public.profiles where id = uid for update;
  if not found then
    raise exception 'no_profile';
  end if;

  select * into c from public.coupons where code = norm and active for update;
  if not found then
    return jsonb_build_object('ok', false, 'error', 'invalid_code');
  end if;

  if c.expires_at is not null and c.expires_at < now() then
    return jsonb_build_object('ok', false, 'error', 'coupon_expired');
  end if;

  if exists (select 1 from public.coupon_redemptions where user_id = uid and code = c.code) then
    return jsonb_build_object('ok', false, 'error', 'already_redeemed');
  end if;

  if c.max_uses is not null and c.uses >= c.max_uses then
    return jsonb_build_object('ok', false, 'error', 'coupon_used_up');
  end if;

  if c.kind = 'pro' then
    update public.profiles set plan = 'pro' where id = uid returning * into p;
    msg := 'Coupon applied: you are now on the Pro plan.';
  else
    update public.profiles set credits = credits + c.value where id = uid returning * into p;
    msg := 'Coupon applied: +' || c.value || ' build credits.';
  end if;

  insert into public.coupon_redemptions (user_id, code) values (uid, c.code);
  update public.coupons set uses = uses + 1 where code = c.code;

  return jsonb_build_object('ok', true, 'plan', p.plan, 'credits', p.credits, 'message', msg);
end;
$$;

revoke all on function public.redeem_coupon(text) from public, anon;
grant execute on function public.redeem_coupon(text) to authenticated;
